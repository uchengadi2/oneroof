<?php

class InstitutionsController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('ListInstitutionsByType','ListAllInstitutionsInACity'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list  institutions by type
         */
        public function actionListInstitutionsByType(){
            
             $model = new Category;
                       
            //get the name of a category
            $category_name = strtolower($model->getCategoryName($_REQUEST['category_id']));
            
                     
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='type=:type and status=:status';
             $criteria->params = array(':type'=>"$category_name",':status'=>"active");
             $criteria->order = "name";
             $institutions= Institutions::model()->findAll($criteria);
             
             
          /**    $targets = [];
             
             foreach($institutions as $institution){
                 if($this->isThisInstitutionAMemberOfThisCategory($institution['id'],$category_name)){
                     $targets[] = $institution;
                 }
             }
           * 
           */
             
             if($institutions===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "institution" => $institutions
                                        
                                
                            ));
                       
                }
        }
        
        
        /**
         * This is the function that determines if an institution is a member of a category
         */
        public function isThisInstitutionAMemberOfThisCategory($institution_id,$category_name){
            $model = new Institutions;
            return $model->isThisInstitutionAMemberOfThisCategory($institution_id,$category_name);
            
        }
        
        
        
        /**
         * This is the function that list institutions  and schools in a city
         */
        public function actionListAllInstitutionsInACity(){
          
            $model = new Category;
            
            $city_id = $_REQUEST['city_id'];
                        
             //get the name of a category
            $category_name = strtolower($model->getCategoryName($_REQUEST['category_id']));
            
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='city_id=:id and type=:type ';
             $criteria->params = array(':id'=>$city_id,':type'=>"$category_name");
             $criteria->order = "name";
             $institutions= Institutions::model()->findAll($criteria);
             
             
             if($institutions===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "institution" => $institutions
                                        
                                
                            ));
                       
                }
        }
}
