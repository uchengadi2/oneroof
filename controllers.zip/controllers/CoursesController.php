<?php

class CoursesController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('ListCoursesbyInstitution','ListPretertiarySchoolCoursesbyCategory','ListSubjectsbyPretertiaryInstitutions',
                                    'listAllCourseForADisciplineForAllInstitutions','listAllCourseDisciplinesForACategoryType','listAllMembersOfThisCourseAssessors',
                                    'getThisCourseAssessorPromise'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
        /**
         * This is the function that list courses by institution
         */
        public function actionListCoursesbyInstitution(){
            
             $model = new Institutions;
                       
            //the id of the institution
            $institution_id = $_REQUEST['institution_id'];
            
                     
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='(institution_id=:instid and classification=:class) and status=:status';
             $criteria->params = array(':instid'=>$institution_id,':class'=>"discipline",':status'=>"active");
             $criteria->order = "name";
             $Courses= Courses::model()->findAll($criteria);
             
             if($Courses===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "course" => $Courses
                                        
                                
                            ));
                       
                }
        }
        
        
        
        
         /**
         * This is the function that list subjects by pre-tertiary institutions
          * 
          **/
        public function actionListSubjectsbyPretertiaryInstitutions(){
            
             $model = new Institutions;
                       
            //the id of the pre tertiary category
            $category_id = $_REQUEST['category_id'];
            
            
            if($model->isThisCategoryPartOfPreTertiary($category_id)){
                
                  //get the institutional id of this category 
                  $institution_id = $model->getTheInstitutionIdOfThisCategory($category_id);
                
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
               $criteria->condition='institution_id=:instid and (classification=:class and status=:status)';
             $criteria->params = array(':instid'=>$institution_id,':class'=>"discipline",':status'=>"active");
                $criteria->order = "name";
                $Courses= Courses::model()->findAll($criteria);
             
             if($Courses===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "subject" => $Courses
                                        
                                
                            ));
                       
                }
                
                
                
            }      
             
        }
        
        
        
        /**
         * This is the function that list pre-tertiary school courses
         */
        public function actionListPretertiarySchoolCoursesbyCategory(){
            
             $model = new Category;
          
             //get the name of a category
            $category_name = strtolower($model->getCategoryName($_REQUEST['category_id']));
            
            
                     
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='type=:type and status=:status';
             $criteria->params = array(':type'=>"$category_name",':status'=>"active");
             $criteria->order = "name";
             $Courses= Courses::model()->findAll($criteria);
             
             if($Courses===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "course" => $Courses
                                        
                                
                            ));
                       
                }
        }
        
        
        
        
         /**
         * This is the function that list all courses for a discipline for all institutions
         */
        public function actionlistAllCourseForADisciplineForAllInstitutions(){
            
             $model = new Courses;
         
             //get the generic course code for this discipline
            $discipline_generic_course_code = strtolower($model->getTheGenericCourseCodeOfThisCourse($_REQUEST['discipline_id']));
            $codes = [];
            $count = 0;
                
            $all_courses = [];
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='(classification=:class and general_course_code=:code) and status=:status';
             $criteria->params = array(':class'=>"course",':code'=>"$discipline_generic_course_code",':status'=>"active");
             $criteria->order = "name";
             $courses= Courses::model()->findAll($criteria);
             
            
             foreach($courses as $course){
                 if(in_array($course['code'],$codes) == false){
                     $all_courses[] = $course;
                     $codes[] = $course['code'];
                     $count = $count + 1;
                 }
             }
             
             
             if($all_courses===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "course" => $all_courses,
                                        "results"=>$count,
                                        
                                
                            ));
                       
                }
        }
        
        
        
        /**
         * This is the function that list all disciplines in a category
         */
        public function actionlistAllCourseDisciplinesForACategoryType(){
            
            $model = new Category;
            
                      //get the code of this category
            
            $all_courses = [];
            $codes = [];
            $count = 0;
            
             $category_code = strtolower($model->getTheCodeOfThisCategory($_REQUEST['category_id']));
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='(type=:type and classification=:classify) and status=:status';
             $criteria->params = array(':type'=>"$category_code",':classify'=>"discipline",':status'=>"active");
             $criteria->order = "name";
             //$criteria->offset = $start;
             //$criteria->limit = $limit;     
             $courses = Courses::model()->findAll($criteria); 
             
             
             foreach($courses as $course){
                 if(in_array($course['general_course_code'],$codes) == false){
                     $all_courses[] = $course;
                     $codes[] = $course['general_course_code'];
                     $count = $count + 1;
                 }
             }
             
                      
                if($courses===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "results"=>$count,
                            "discipline" => $all_courses)
                       );
                       
                }
            
        }
        
        
        /**
         * This is the function that list the assessors of a course
         */
        public function actionlistAllMembersOfThisCourseAssessors(){
            $model = new SubCourses;
            
            //get the subcourse id
            
            $sub_course_id = $_REQUEST['course_id'];
            
            $all_assessors = [];
            
                       
            //get the course id  for this subcourse
            
            $course_code = $model->getTheCourseCodeForThisSubCourse($sub_course_id);
            
            
            //get all the courses related by this code
            $all_courses = $this->getAllTheCoursesWithThisCode($course_code);
            
            //rerieve all the assessors that are active on this course
            
            foreach($all_courses as $course){
                //get the assessors details
                $assessors = $this->getAllTheActiveAssessorsOnThisCourse($course);
                foreach($assessors as $assessor){
                    $all_assessors[] = $this->getTheDetailsOfThisAssessor($assessor); 
                }
            }
            
           
            
             if($all_assessors===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "assessor" => $all_assessors)
                       );
                       
                }
            
            
            
        }
        
        
        /**
         * This is the function that retrieves all active assessors for a course
         */
        public function getAllTheActiveAssessorsOnThisCourse($course_id){
            $model = new AssessorHasCourses;
            return $model->getAllTheActiveAssessorsOnThisCourse($course_id);
        }
        
        
        /**
         * This is the function that gets all the courses with same code
         */
        public function getAllTheCoursesWithThisCode($course_code){
            $model = new Courses;
            return $model->getAllTheCoursesWithThisCode($course_code);
        }
        
        
        /**
         * This is the function that retrieves the details of assessors
         */
        public function getTheDetailsOfThisAssessor($assessor){
            $model = new Members;
            return $model->getTheDetailsOfThisAssessor($assessor);
        }
        
        
        /**
         * This is the function that retrieves an assessor's promise on a course
         */
        public function actiongetThisCourseAssessorPromise(){
            
            $model = new AssessorHasCourses;
            
            //get the corresponding course of this subcourse
            
            $course_id = $this->getThisSubcourseCourseId($_REQUEST['sub_course_id']);
            
            $promise = $model->getTheCoursePromiseOfThisAssessor($course_id,$_REQUEST['assessor_id']);
            
            header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                            "promise" => $promise,
                            "course_id"=>$course_id)
                       );
        }
        
        
        /**
         * This is the function that retrieves a course id from a subcourse
         */
        public function getThisSubcourseCourseId($sub_course_id){
            $model = new SubCourses;
            return $model->getThisSubcourseCourseId($sub_course_id);
            
        }
}
