<?php

class InstitutionController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','removeinstitution','addnewinstitution','modifythisinstitution','listAllInstitutions','listAllPreferenceInstitutions'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}
        
        
         /**
         * This is the function that add a new institution for a preference
         */
        public function actionaddnewinstitution()
	{
            $model=new Institution;
            
            $user_id = Yii::app()->user->id;

		
              $model->name = $_POST['name'];
              $model->preference_id = $_POST['preference'];
              $model->description = $_POST['description'];
              $model->create_time = new CDbExpression('NOW()');
              $model->create_user_id =$user_id;
                
                if($model->save()){
                     //$data['success'] = 'false';
                     $msg = 'New Institution is successfully added';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                  }else{
                       //$result['success'] = 'false';
                         $msg = 'This institution was not added, please check with your field validations';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }
               
	}
        
        
         /**
         * This is the function that modifies an institution
         */
        public function actionmodifythisinstitution()
	{
            $_id = $_POST['id'];
            $model=  Institution::model()->findByPk($_id);
            
            $user_id = Yii::app()->user->id;
            
            if(is_numeric($_POST['preference'])){
                $preference = $_POST['preference'];
            }else{
                $preference = $_POST['preference_id'];
            }

		
              $model->name = $_POST['name'];
              $model->preference_id = $preference;
              $model->description = $_POST['description'];
              $model->update_time = new CDbExpression('NOW()');
              $model->update_user_id =$user_id;
                
                if($model->save()){
                     //$data['success'] = 'false';
                     $msg = 'Institution is successfully modified';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                  }else{
                       //$result['success'] = 'false';
                         $msg = 'This institution was not modified, please check with your field validations';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }
               
	}
        
        
        
        /**
	 * removes a particular institution model.
	
	 */
	public function actionremoveinstitution()
	{
            $_id = $_POST['id'];
            $model= Institution::model()->findByPk($_id);
            
            //get the name of this institution
            $institution_name = $model->getTheNameOfThisInstitution($_id);
            
           if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$institution_name' institution is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
	}
	
        
        
        /**
         * This is the function that list all institutions
         */
        public function actionlistAllInstitutions(){
            
            $institution = Institution::model()->findAll();
                if($institution===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "institution" =>$institution
                                        
                                
                            ));
                       
                }
            
        }
        
        
        /**
         * This is the function that list all institution for a preference
         */
        public function actionlistAllPreferenceInstitutions(){
            
             $prefernce_id = $_REQUEST['preference_id'];
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='preference_id=:id';
                $criteria->params = array(':id'=>$prefernce_id);
                $institutions= Institution::model()->findAll($criteria);
                
                if($institutions===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                             "institution" => $institutions)
                       );
                       
                }
        }

	
        
}
