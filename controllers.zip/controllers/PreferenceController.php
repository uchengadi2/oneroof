<?php

class PreferenceController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','removepreference','addnewpreference','modifypreference','listAllPreferences'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

        /**
         * This is the function that add a new preference
         */
        public function actionaddnewpreference()
	{
            $model=new Preference;
            
            $user_id = Yii::app()->user->id;

		
              $model->name = $_POST['name'];
              $model->description = $_POST['description'];
              $model->create_time = new CDbExpression('NOW()');
              $model->create_user_id =$user_id;
                
                if($model->save()){
                     //$data['success'] = 'false';
                     $msg = 'New preference is successfully added';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                  }else{
                       //$result['success'] = 'false';
                         $msg = 'This preference was not added, please check with your field validations';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }
               
	}
        
        
         /**
         * This is the function that modifies a preference
         */
        public function actionmodifypreference()
	{
            $_id = $_POST['id'];
            $model= Preference::model()->findByPk($_id);
            
            $user_id = Yii::app()->user->id;

		
              $model->name = $_POST['name'];
              $model->description = $_POST['description'];
              $model->update_time = new CDbExpression('NOW()');
              $model->update_user_id =$user_id;
                
                if($model->save()){
                     //$data['success'] = 'false';
                     $msg = 'Preference is successfully modified';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                  }else{
                       //$result['success'] = 'false';
                         $msg = 'This preference was not modified, please check with your field validations';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }
               
	}
        
        
        
        /**
	 * removes a particular preference model.
	
	 */
	public function actionremovepreference()
	{
            $_id = $_POST['id'];
            $model=  Preference::model()->findByPk($_id);
            
            //get the name of this city
            $preference_name = $model->getTheNameOfThisPreference($_id);
            
           if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$preference_name' preference is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
	}
	
        
        
        /**
         * This is the function that list all preference
         */
        public function actionlistAllPreferences(){
            
            $preference = Preference::model()->findAll();
                if($preference===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "preference" => $preference
                                        
                                
                            ));
                       
                }
            
        }
}
