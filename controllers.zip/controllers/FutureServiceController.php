<?php

class FutureServiceController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','submittingemailaddressforafutureservice'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

        /**
         * This is the function that submits the email address of a student that needs a future services
         */
        public function actionsubmittingemailaddressforafutureservice(){
            
            $model = new FutureService;
            
            $user_id = Yii::app()->user->id;
            
            $model->preference_id = $_POST['preference_id'];
            $model->institution_id = $_POST['institution_id'];
            $model->discipline_id = $_POST['discipline_id'];
            $model->course_id = $_POST['course_id'];
            $model->service_id = $_POST['service_id'];
            $model->service_type = $_POST['service_type'];
            $model->email_address = $_POST['email_address'];
            $model->student_id = $user_id;
            
            if($model->save()){
                     //$data['success'] = 'false';
                     $msg = "Email address submitted successfully. You will surely be among the first to know when this '$model->service_type' service is activated on this course";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                  }else{
                       //$result['success'] = 'false';
                         $msg = 'Could not submit your email address. please check with your field type for correctness';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }
        }
	
}
