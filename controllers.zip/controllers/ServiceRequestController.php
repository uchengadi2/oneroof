<?php

class ServiceRequestController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','placingexpertassessmentrequest','placingsupervisedmockexaminationrequest','placingunsupervisedmockexaminationrequest',
                                    'placinganrepertopiniononownmockexaminationrequest','placinganrepertopiniononownassessmentrequest','submittingassessmentassignment'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that places expert assessment request
         */
        public function actionplacingexpertassessmentrequest(){
            $model = new ServiceRequest;
            
            $user_id = Yii::app()->user->id;
            
            $model->service_id = $_POST['service_id'];
            $model->course_id = $_POST['course_id'];
            $model->discipline_id = $_POST['discipline_id'];
            $model->institution_id = $_POST['institution_id'];
            $model->student_id = $user_id;
            $model->difficulty =$_POST['difficulty'];
            $model->date_requested = new CDbExpression('NOW()');
            $model->requested_by = $user_id;
           if(isset($_POST['assessment_request_limit'])){
               $model->assessment_request_limit = $_POST['assessment_request_limit'];
           }else{
               $model->assessment_request_limit = NULL;
           }
           $model->is_service_supervisory_learning = 0;
           
           if($_POST['is_subscription_active']== 'false'){
               if($_POST['payment_method'] == 'bank'){
                   if($_POST['payment_type'] == "subscription"){
                   //suubscribe to the service and make payment
                if($this->isSubscriptionToThisServiceForThisUserASuccess($user_id,$model->service_id,$model->course_id,$_POST['frequency'])){
                  if($this->isPaymentASuccess($user_id,$_POST['service_id'],$model->course_id,$_POST['amount'],$_POST['payment_type'],$_POST['payment_method'])){
                       $model->service_request_code = strtoupper($model->generateThisServiceRequestCode($model->service_id,$model->institution_id));   
                   if($model->save()){
                       $msg = "Your expert assessment request have been recieved. Please use this '$model->service_request_code' service request code for your bank payment.However your assesment request will be ready 48 hours after payment confirmation ";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                  }else{
                       //$result['success'] = 'false';
                         $msg = "There seems to be validation issues in the data your provided. Please check the data fields and try again or contact customer service for assistance";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }
               
                          
                      }else{
                           $msg = "We have issues trying to register this payment. Please kindly try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                          
                      }//payment not successful
                   }else{
                        $msg = "We have issues trying to initiate this subscription. Please kindly try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                          
                   }
               }else{
                    if($this->isPaymentASuccess($user_id,$_POST['service_id'],$model->course_id,$_POST['amount'],$_POST['payment_type'],$_POST['payment_method'])){
                      $model->service_request_code = strtoupper($model->generateThisServiceRequestCode( $model->service_id,$model->institution_id));       
                     if($model->save()){
                       $msg = "Your expert assessment request have been recieved. Please use this '$model->service_request_code' service request code for your bank payment.However your assesment request will be ready 48 hours after payment confirmation ";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                  }else{
                       //$result['success'] = 'false';
                         $msg = "There seems to be validation issues in the data your provided. Please check the data fields and try again or contact customer service for assistance";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }
                      }else{
                          $msg = "We have issues trying to register this payment. Please kindly try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                          
                      }//payment not successful
                   
               }
                   
                   
               }else{
                   //online payment here
                   $msg = "Just testing stuff out";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                   
               }
               
               
           }else{
                   $model->service_request_code = strtoupper($model->generateThisServiceRequestCode( $model->service_id,$model->institution_id));   
                   if($model->save()){
                       $msg = "Your expert assessment request have been recieved. Please use this '$model->service_request_code' service request code for your bank payment.However your assesment request will be ready 48 hours after payment confirmation ";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                  }else{
                       //$result['success'] = 'false';
                         $msg = "There seems to be validation issues in the data your provided. Please check the data fields and try again or contact customer service for assistance";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }
               
               
           }
           
           
        }
        
        
        
        /**
         * This is the function that confirms if a subscription is successful or not
         */
        public function isSubscriptionToThisServiceForThisUserASuccess($user_id,$service_id,$course_id,$frequency){
            $model = new ServiceSubscription;
            return $model->isSubscriptionToThisServiceForThisUserASuccess($user_id,$service_id,$course_id,$frequency);
        }
        
        /**
         * This is the function that confirms if service payment
         */
        public function isPaymentASuccess($user_id,$service_id,$course_id,$amount,$payment_type,$payment_method){
            $model = new ServicePayment;
            return $model->isPaymentASuccess($user_id,$service_id,$course_id,$amount,$payment_type,$payment_method);
        }
        
        
        /**
         * This is the function that places supervised mock examination request
         */
        public function actionplacingsupervisedmockexaminationrequest(){
            $model = new ServiceRequest;
            
            $user_id = Yii::app()->user->id;
            
            $model->service_id = $_POST['service_id'];
            $model->course_id = $_POST['course_id'];
            $model->discipline_id = $_POST['discipline_id'];
            $model->institution_id = $_POST['institution_id'];
            $model->student_id = $user_id;
            $model->difficulty =$_POST['difficulty'];
            $model->date_requested = new CDbExpression('NOW()');
            $model->requested_by = $user_id;
           if(isset($_POST['assessment_request_limit'])){
               $model->assessment_request_limit = $_POST['assessment_request_limit'];
           }else{
               $model->assessment_request_limit = NULL;
           }
           $model->is_service_supervisory_learning = 0;
           
           if($_POST['is_subscription_active']== 'false'){
               if($_POST['payment_method'] == 'bank'){
                   if($_POST['payment_type'] == "subscription"){
                   //suubscribe to the service and make payment
                if($this->isSubscriptionToThisServiceForThisUserASuccess($user_id,$model->service_id,$model->course_id,$_POST['frequency'])){
                  if($this->isPaymentASuccess($user_id,$_POST['service_id'],$model->course_id,$_POST['amount'],$_POST['payment_type'],$_POST['payment_method'])){
                       $model->service_request_code = strtoupper($model->generateThisServiceRequestCode($model->service_id,$model->institution_id));   
                   if($model->save()){
                       $msg = "Your supervised mock examination request have been recieved. Please use this '$model->service_request_code' service request code for your bank payment.However your mock examination request will be ready 48 hours after payment confirmation ";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                  }else{
                       //$result['success'] = 'false';
                         $msg = "There seems to be validation issues in the data your provided. Please check the data fields and try again or contact customer service for assistance";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }
               
                          
                      }else{
                           $msg = "We have issues trying to register this payment. Please kindly try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                          
                      }//payment not successful
                   }else{
                        $msg = "We have issues trying to initiate this subscription. Please kindly try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                          
                   }
               }else{
                    if($this->isPaymentASuccess($user_id,$_POST['service_id'],$model->course_id,$_POST['amount'],$_POST['payment_type'],$_POST['payment_method'])){
                      $model->service_request_code = strtoupper($model->generateThisServiceRequestCode( $model->service_id,$model->institution_id));       
                     if($model->save()){
                       $msg = "Your supervised mock examination request have been recieved. Please use this '$model->service_request_code' service request code for your bank payment.However your mock examination request will be ready 48 hours after payment confirmation ";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                  }else{
                       //$result['success'] = 'false';
                         $msg = "There seems to be validation issues in the data your provided. Please check the data fields and try again or contact customer service for assistance";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }
                      }else{
                          $msg = "We have issues trying to register this payment. Please kindly try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                          
                      }//payment not successful
                   
               }
                   
                   
               }else{
                   //online payment here
                   $msg = "Just testing stuff out";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                   
               }
               
               
           }else{
                   $model->service_request_code = strtoupper($model->generateThisServiceRequestCode( $model->service_id,$model->institution_id));   
                   if($model->save()){
                       $msg = "Your supervised mock examination request have been recieved. Please use this '$model->service_request_code' service request code for your bank payment.However your mock examination request will be ready 48 hours after payment confirmation ";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                  }else{
                       //$result['success'] = 'false';
                         $msg = "There seems to be validation issues in the data your provided. Please check the data fields and try again or contact customer service for assistance";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }
               
               
           }
           
           
        }
        
        
        
        
        
         /**
         * This is the function that places unsupervised mock examination request
         */
        public function actionplacingunsupervisedmockexaminationrequest(){
            $model = new ServiceRequest;
            
            $user_id = Yii::app()->user->id;
            
            $model->service_id = $_POST['service_id'];
            $model->course_id = $_POST['course_id'];
            $model->discipline_id = $_POST['discipline_id'];
            $model->institution_id = $_POST['institution_id'];
            $model->student_id = $user_id;
            $model->difficulty =$_POST['difficulty'];
            $model->date_requested = new CDbExpression('NOW()');
            $model->requested_by = $user_id;
           if(isset($_POST['assessment_request_limit'])){
               $model->assessment_request_limit = $_POST['assessment_request_limit'];
           }else{
               $model->assessment_request_limit = NULL;
           }
           $model->is_service_supervisory_learning = 0;
           
           if($_POST['is_subscription_active']== 'false'){
               if($_POST['payment_method'] == 'bank'){
                   if($_POST['payment_type'] == "subscription"){
                   //suubscribe to the service and make payment
                if($this->isSubscriptionToThisServiceForThisUserASuccess($user_id,$model->service_id,$model->course_id,$_POST['frequency'])){
                  if($this->isPaymentASuccess($user_id,$_POST['service_id'],$model->course_id,$_POST['amount'],$_POST['payment_type'],$_POST['payment_method'])){
                       $model->service_request_code = strtoupper($model->generateThisServiceRequestCode($model->service_id,$model->institution_id));   
                   if($model->save()){
                       $msg = "Your unsupervised mock examination request have been recieved. Please use this '$model->service_request_code' service request code for your bank payment.However your mock examination request will be ready 48 hours after payment confirmation ";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                  }else{
                       //$result['success'] = 'false';
                         $msg = "There seems to be validation issues in the data your provided. Please check the data fields and try again or contact customer service for assistance";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }
               
                          
                      }else{
                           $msg = "We have issues trying to register this payment. Please kindly try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                          
                      }//payment not successful
                   }else{
                        $msg = "We have issues trying to initiate this subscription. Please kindly try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                          
                   }
               }else{
                    if($this->isPaymentASuccess($user_id,$_POST['service_id'],$model->course_id,$_POST['amount'],$_POST['payment_type'],$_POST['payment_method'])){
                      $model->service_request_code = strtoupper($model->generateThisServiceRequestCode( $model->service_id,$model->institution_id));       
                     if($model->save()){
                       $msg = "Your unsupervised mock examination request have been recieved. Please use this '$model->service_request_code' service request code for your bank payment.However your mock examination request will be ready 48 hours after payment confirmation ";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                  }else{
                       //$result['success'] = 'false';
                         $msg = "There seems to be validation issues in the data your provided. Please check the data fields and try again or contact customer service for assistance";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }
                      }else{
                          $msg = "We have issues trying to register this payment. Please kindly try again or contact customer service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                          
                      }//payment not successful
                   
               }
                   
                   
               }else{
                   //online payment here
                   $msg = "Just testing stuff out";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                   
               }
               
               
           }else{
                   $model->service_request_code = strtoupper($model->generateThisServiceRequestCode( $model->service_id,$model->institution_id));   
                   if($model->save()){
                       $msg = "Your unsupervised mock examination request have been recieved. Please use this '$model->service_request_code' service request code for your bank payment.However your mock examination request will be ready 48 hours after payment confirmation ";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                  }else{
                       //$result['success'] = 'false';
                         $msg = "There seems to be validation issues in the data your provided. Please check the data fields and try again or contact customer service for assistance";
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }
               
               
           }
           
           
        }
        
        
        /**
         * This is the function that submits an assessment request
         */
        public function actionsubmittingassessmentassignment(){
            
            if($this->isServiceRequestCodeLegitimate($_REQUEST['service_request_code'])){
                if($_FILES['filename']['name'] != ""){
                     $service_id = $this->retriveThisServiceId($_REQUEST['service_request_code']);
                    $model= ServiceRequest::model()->findByPk($service_id);
            
                $error_counter = 0;
                // This is the funstion that uploads a zipped file 
                 if($_FILES['filename']['name'] != ""){
                    if($model->isFileValidationASuccess()){
                        
                       $filename = $_FILES['filename']['name'];
                                             
                    }else{
                       
                        $error_counter = $error_counter + 1;
                         
                    }//end of the file valoidation
                }else{
                    $error_counter = $error_counter + 1;
                  
             
                }
                if($error_counter == 0){
                    
                     if($model->validate()){
                         $model->filename = $model->moveThisZippedFileToItsPathAndObtainTheFolder($model, $filename);
                    
                    }
                  if($model->save()){
                     //$data['success'] = 'false';
                     $msg = 'Your submission was successful';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg
                                  )
                           );
                  }else{
                       //$result['success'] = 'false';
                         $msg = 'Assignment submission was not successful. Please check with your data fields and try again';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }
                }else{
                    
                   //$result['success'] = 'false';
                         $msg = 'Assignment submission was not successful. It is possible you were attempting to submit a non zipped file. Check the file for correctness and try again';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                }
                    
                    
                }else{
                     //$result['success'] = 'false';
                         $msg = 'You did not attached any file. Kindly attach a zipped file and try again';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                }
               
                
                
            }else{
                //$result['success'] = 'false';
                         $msg = 'Wrong Service Request Code: You provided a service request code that is not correct. Please check the code and try again';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                
            }
            
            
               
            
             
        }
        
        /**
         * This is the function that retrieves a service id given its service request code
         */
        public function retriveThisServiceId($service_request_code){
            $model = new ServiceRequest;
            return $model->retriveThisServiceId($service_request_code);
            
        }
        
        
        /**
         * This is the function that determines if a service request code is valid or not
         */
        public function isServiceRequestCodeLegitimate($service_request_code){
            $model = new ServiceRequest;
            return $model->isServiceRequestCodeLegitimate($service_request_code);
        }
}
