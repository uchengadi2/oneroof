<?php

class SubscriptionTypeController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','removeservicesubscriptiontype','addnewservicesubscriptiontype','modifyservicesubscriptiontype','listAllSubscriptionTypes','listAllServiceSubscriptionTypes'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}
        
        
         /**
         * This is the function that add a new subscription type for a service
         */
        public function actionaddnewservicesubscriptiontype()
	{
            $model=new SubscriptionType;
            
            $user_id = Yii::app()->user->id;

		
              $model->name = $_POST['name'];
              $model->service_id = $_POST['service'];
              $model->amount = $_POST['amount'];
              $model->frequency = $_POST['frequency'];
              $model->is_assessor_pricing_preferred = $_POST['is_assessor_pricing_preferred'];
              $model->create_time = new CDbExpression('NOW()');
              $model->create_user_id =$user_id;
                
                if($model->save()){
                     //$data['success'] = 'false';
                     $msg = 'New service subscription type is successfully added';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                  }else{
                       //$result['success'] = 'false';
                         $msg = 'This service subscription type was not added, please check with your field validations';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }
               
	}
        
        
         /**
         * This is the function that modifies a service subscription type
         */
        public function actionmodifyservicesubscriptiontype()
	{
            $_id = $_POST['id'];
            $model= SubscriptionType::model()->findByPk($_id);
            
            $user_id = Yii::app()->user->id;
            
            if(is_numeric($_POST['service'])){
                $service = $_POST['service'];
            }else{
                $service = $_POST['service_id'];
            }

		
              $model->name = $_POST['name'];
              $model->service_id = $service;
              $model->amount = $_POST['amount'];
              $model->frequency = $_POST['frequency'];
              $model->is_assessor_pricing_preferred = $_POST['is_assessor_pricing_preferred'];
              $model->update_time = new CDbExpression('NOW()');
              $model->update_user_id =$user_id;
                
                if($model->save()){
                     //$data['success'] = 'false';
                     $msg = 'Service subscription type is successfully modified';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                  }else{
                       //$result['success'] = 'false';
                         $msg = 'This service subscription type was not modified, please check with your field validations';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }
               
	}
        
        
        
        /**
	 * removes a particular service subscription type model.
	
	 */
	public function actionremoveservicesubscriptiontype()
	{
            $_id = $_POST['id'];
            $model= SubscriptionType::model()->findByPk($_id);
            
            //get the name of this service subscription type
            $type_name = $model->getTheNameOfThisSubscriptionType($_id);
            
           if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$service_name' service subscription type is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
	}
	
        
        
        /**
         * This is the function that list all services subscription type
         */
        public function actionlistAllSubscriptionTypes(){
            
            $types = SubscriptionType::model()->findAll();
                if($types===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "type" =>$types
                                        
                                
                            ));
                       
                }
            
        }
        
        
        /**
         * This is the function that list all subscription types for a service
         */
        public function actionlistAllServiceSubscriptionTypes(){
            
                $service_id = $_REQUEST['service_id'];
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='service_id=:id';
                $criteria->params = array(':id'=>$service_id);
                $types= SubscriptionType::model()->findAll($criteria);
                
                if($types===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                             "type" => $types)
                       );
                       
                }
        }

	
}
