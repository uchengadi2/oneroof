<?php

class SettingsController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','removesettings','addnewsettings','modifysettings','istAllSettings'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that add a new settings
         */
        public function actionaddnewsettings()
	{
            $model=new Preference;
            
            $user_id = Yii::app()->user->id;

		
              $model->maximum_untreated_assessment_for_an_assessor = $_POST['maximum_untreated_assessment_for_an_assessor'];
              $model->maximum_untreated_mock_for_an_assessor = $_POST['maximum_untreated_mock_for_an_assessor'];
              $model->maximum_open_supervisory_service_for_an_assessor = $_POST['maximum_open_supervisory_service_for_an_assessor'];
              $model->is_assessor_pricing_preferred_for_assessment_services = $_POST['is_assessor_pricing_preferred_for_assessment_services'];
              $model->is_assessor_pricing_preferred_for_mock_services = $_POST['is_assessor_pricing_preferred_for_mock_services'];
              $model->is_assessor_pricing_preferred_for_supervisory_services = $_POST['is_assessor_pricing_preferred_for_supervisory_services'];
              //$model->status = $_POST['status'];
              $model->create_time = new CDbExpression('NOW()');
              $model->create_user_id =$user_id;
                
                if($mode->save()){
                     //$data['success'] = 'false';
                     $msg = 'New settings is successfully added';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                  }else{
                       //$result['success'] = 'false';
                         $msg = 'This settings was not added, please check with your field validations';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }
               
	}
        
        
         /**
         * This is the function that modifies a settings
         */
        public function actionmodifysettings()
	{
            $_id = $_POST['id'];
            $model=Settings::model()->findByPk($_id);
            
            $user_id = Yii::app()->user->id;

		
              $model->maximum_untreated_assessment_for_an_assessor = $_POST['maximum_untreated_assessment_for_an_assessor'];
              $model->maximum_untreated_mock_for_an_assessor = $_POST['maximum_untreated_mock_for_an_assessor'];
              $model->maximum_open_supervisory_service_for_an_assessor = $_POST['maximum_open_supervisory_service_for_an_assessor'];
              $model->is_assessor_pricing_preferred_for_assessment_services = $_POST['is_assessor_pricing_preferred_for_assessment_services'];
              $model->is_assessor_pricing_preferred_for_mock_services = $_POST['is_assessor_pricing_preferred_for_mock_services'];
              $model->is_assessor_pricing_preferred_for_supervisory_services = $_POST['is_assessor_pricing_preferred_for_supervisory_services'];
              $model->update_time = new CDbExpression('NOW()');
              $model->update_user_id =$user_id;
                
                if($mode->save()){
                     //$data['success'] = 'false';
                     $msg = 'Settings is successfully modified';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                  }else{
                       //$result['success'] = 'false';
                         $msg = 'This settings was not modified, please check with your field validations';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }
               
	}
        
        
        
        /**
	 * removes a particular settings model.
	
	 */
	public function actionremovesettings()
	{
            $_id = $_REQUEST['id'];
            $model=  Settings::model()->findByPk($_id);
            
                     
           if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "This setting is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
	}
	
        
        
        /**
         * This is the function that list all settings
         */
        public function actionistAllSettings(){
            
            $settings = Settings::model()->findAll();
                if($settings===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "settings" => $settings
                                        
                                
                            ));
                       
                }
            
        }
        
        
        /**
         * This is the function that activates a setting
         */
        public function actionactivatethisetting(){
            
            $_id = $_REQUEST['id'];
            $model=  Settings::model()->findByPk($_id);
            
            if($this->isAllSettingsDeactivatedSuccessfully()){
                $model->status = "active";
                if($model->save()){
                    header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => "settings is activated successfully"
                                        
                                
                            ));
                }else{
                     echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => "Could not activate this settings. Please contact customers  service"
                                        
                                
                            ));
                }
                
            }else{
                 echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => "Could not activate this settings. Please contact customers  service"
                                        
                                
                            ));
            }
            
            
        }
        
        
        /**
         * This is the function that deacrivates all settings
         */
        public function isAllSettingsDeactivatedSuccessfully(){
            $model = new Settings;
            return $model->isAllSettingsDeactivatedSuccessfully();
        }
}
