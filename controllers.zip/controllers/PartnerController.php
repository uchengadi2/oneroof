<?php

class PartnerController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','ApplicatioForSmePartnership','ApplicatioForArtistPartnership'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that saves the application to become Subject Matter Expert
         */
        public function actionApplicatioForSmePartnership(){
            
            $model = new Partner;
            
            $model->email_address = $_REQUEST['email_address'];
            $model->phone_number = $_REQUEST['phone_number'];
            $model->specialization = $_REQUEST['specialization'];
            $model->qualification = $_REQUEST['qualification'];
            $model->experience = $_REQUEST['experience'];
            $model->course_id = $_REQUEST['course'];
            $model->name = $_REQUEST['name'];
            $model->date_submitted = new CDbExpression('NOW()');
            $model->type = "sme";
            
                  
            
                   if($model->validate()){
                                             
                       if($model->save()) {
                        
                                $msg = "We have recieved your request to become a Subject Matter Expert on Oneroof Platform. We will review your applicatiion and contact you if you are successful";
                                // header('Content-Type: application/json');
                                 header('Content-Type: text/html');
                                echo CJSON::encode(array(
                                 "success" => mysql_errno() == 0,
                                  "msg" => $msg)
                            );
                         
                        }else{
                            $msg = 'Validaion Error: Check your file fields for correctness';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                               );
                          }
                            }else{
                                
                               
                            $msg = "Validation Error: Your application could not be processed. Please ensure you entered the information as requested and try again. You could contact the Customer Service Desk for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                     
            
        }
        
        /**
         * This is the function that saves the application to become Artist content Partner
         */
        public function actionApplicatioForArtistPartnership(){
            
            $model = new Partner;
            
                      
            $model->email_address = $_REQUEST['email_address'];
            $model->phone_number = $_REQUEST['phone_number'];
            $model->specialization = $_REQUEST['specialization'];
            $model->qualification = $_REQUEST['qualification'];
            $model->experience = $_REQUEST['experience'];
            $model->course_id = $_REQUEST['course'];
            $model->name = $_REQUEST['name'];
            $model->date_submitted = new CDbExpression('NOW()');
            $model->type = "artist";
            
           
           
                   if($model->validate()){
                                               
                       if($model->save()) {
                        
                                $msg = "We have recieved your request to become a Graphic Content Partner on Oneroof Platform. We will review your applicatiion and contact you if you are successful";
                                 //header('Content-Type: application/json');
                                 header('Content-Type: text/html');
                                echo CJSON::encode(array(
                                 "success" => mysql_errno() == 0,
                                  "msg" => $msg)
                            );
                         
                        }else{
                            $msg = 'Validaion Error: Check your file fields for correctness';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                               );
                          }
                            }else{
                                
                               
                            $msg = "Validation Error: Your application could not be processed. Please ensure you entered the information as requested and try again. You could contact the Customer Service Desk for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                       
            
        }
}
