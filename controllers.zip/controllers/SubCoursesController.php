<?php

class SubCoursesController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','retrieveallsubcoursesforacourse'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
        
         /**
         * This is the function that list courses by institution
         */
        public function actionretrieveallsubcoursesforacourse(){
            
             $model = new Courses;
                      
             $institution_id = $_REQUEST['institution_id'];
                     
            //retrieve all the non discipline courses with this generic ciode
                                     
            $non_decipline_courses = $model->getAllTheNonDiscioplineCoursesOfThisDisciplineCourse($_REQUEST['course_id'],$institution_id);
            
            $all_course = [];
            
            foreach($non_decipline_courses as $course){
                
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='course_id=:courseid and status=:status';
                $criteria->params = array(':courseid'=>$course,':status'=>"active");
                $criteria->order = "name";
                $courses= SubCourses::model()->findAll($criteria);
                
                foreach($courses as $course){
                    $all_course[] = $course;
                }
                
                
                
            }
            
                      
             if($all_course===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "course" => $all_course
                                        
                                
                            ));
                       
                }
        }
        
}
