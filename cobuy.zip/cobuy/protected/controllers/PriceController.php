<?php

class PriceController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','addnewserviceprice','modifyserviceprice','listAllPrices','listAllServicePrices'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that add a new service price
         */
        public function actionaddnewserviceprice()
	{
            $model=new Price;
            
            $user_id = Yii::app()->user->id;

		
              $model->service_id = $_POST['service'];
              $model->per_transaction_amount = $_POST['per_transaction_amount'];
              $model->is_assessor_pricing_preferred = $_POST['is_assessor_pricing_preferred'];
              $model->create_time = new CDbExpression('NOW()');
              $model->create_user_id =$user_id;
                
                if($model->save()){
                     //$data['success'] = 'false';
                     $msg = 'New Service Price is successfully added';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                  }else{
                       //$result['success'] = 'false';
                         $msg = 'This service price was not added, please check with your field validations';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }
               
	}
        
        
         /**
         * This is the function that modifies a service
         */
        public function actionmodifyservice()
	{
            $_id = $_POST['id'];
            $model= Price::model()->findByPk($_id);
            
            $user_id = Yii::app()->user->id;
            
            if(is_numeric($_POST['service'])){
                $service = $_POST['service'];
            }else{
                $service = $_POST['service_id'];
            }

		
              $model->service_id =$service;
              $model->per_transaction_amount = $_POST['per_transaction_amount'];
              $model->is_assessor_pricing_preferred = $_POST['is_assessor_pricing_preferred'];
              $model->update_time = new CDbExpression('NOW()');
              $model->update_user_id =$user_id;
                
                if($model->save()){
                     //$data['success'] = 'false';
                     $msg = 'Service price is successfully modified';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                  }else{
                       //$result['success'] = 'false';
                         $msg = 'This service price  was not modified, please check with your field validations';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }
               
	}
        
        
         
        
        /**
         * This is the function that list all services prices
         */
        public function actionlistAllPrices(){
            
            $prices = Price::model()->findAll();
                if($prices===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "price" =>$prices
                                        
                                
                            ));
                       
                }
            
        }
        
        
        /**
         * This is the function that list all prices for a service
         */
        public function actionlistAllServicePrices(){
            
                $service_id = $_REQUEST['service_id'];
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='service_id=:id';
                $criteria->params = array(':id'=>$service_id);
                $prices= Price::model()->findAll($criteria);
                
                if($prices===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                             "price" => $prices)
                       );
                       
                }
        }
}
