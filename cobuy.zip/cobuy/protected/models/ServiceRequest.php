<?php

/**
 * This is the model class for table "service_request".
 *
 * The followings are the available columns in table 'service_request':
 * @property string $id
 * @property string $service_id
 * @property string $student_id
 * @property string $payment_status
 * @property integer $is_request_selected_by_assessor
 * @property integer $is_service_supervisory_learning
 * @property string $enrollment_date
 * @property integer $enrolled_by
 * @property string $filename
 *
 * The followings are the available model relations:
 * @property Members[] $members
 * @property Service $service
 * @property Members $student
 */
class ServiceRequest extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'service_request';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('service_id, student_id, payment_status', 'required'),
			array('is_request_selected_by_assessor, is_service_supervisory_learning, enrolled_by', 'numerical', 'integerOnly'=>true),
			array('service_id, student_id', 'length', 'max'=>10),
			array('payment_status', 'length', 'max'=>11),
			array('filename', 'length', 'max'=>200),
			array('enrollment_date', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, service_id, student_id, payment_status, is_request_selected_by_assessor, is_service_supervisory_learning, enrollment_date, enrolled_by, filename', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'members' => array(self::MANY_MANY, 'Members', 'assessor_has_request(service_request_id, assessor_id)'),
			'service' => array(self::BELONGS_TO, 'Service', 'service_id'),
			'student' => array(self::BELONGS_TO, 'Members', 'student_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'service_id' => 'Service',
			'student_id' => 'Student',
			'payment_status' => 'Payment Status',
			'is_request_selected_by_assessor' => 'Is Request Selected By Assessor',
			'is_service_supervisory_learning' => 'Is Service Supervisory Learning',
			'enrollment_date' => 'Enrollment Date',
			'enrolled_by' => 'Enrolled By',
			'filename' => 'Filename',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('service_id',$this->service_id,true);
		$criteria->compare('student_id',$this->student_id,true);
		$criteria->compare('payment_status',$this->payment_status,true);
		$criteria->compare('is_request_selected_by_assessor',$this->is_request_selected_by_assessor);
		$criteria->compare('is_service_supervisory_learning',$this->is_service_supervisory_learning);
		$criteria->compare('enrollment_date',$this->enrollment_date,true);
		$criteria->compare('enrolled_by',$this->enrolled_by);
		$criteria->compare('filename',$this->filename,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return ServiceRequest the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
}
