<?php

/**
 * This is the model class for table "settings".
 *
 * The followings are the available columns in table 'settings':
 * @property string $id
 * @property integer $maximum_untreated_assessment_for_an_assessor
 * @property integer $maximum_untreated_mock_for_an_assessor
 * @property integer $maximum_open_supervisory_service_for_an_assessor
 * @property integer $is_assessor_pricing_preferred_for_assessment_services
 * @property integer $is_assessor_pricing_preferred_for_mock_services
 * @property integer $is_assessor_pricing_preferred_for_supervisory_services
 * @property string $status
 */
class Settings extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'settings';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('status', 'required'),
			array('maximum_untreated_assessment_for_an_assessor, maximum_untreated_mock_for_an_assessor, maximum_open_supervisory_service_for_an_assessor, is_assessor_pricing_preferred_for_assessment_services, is_assessor_pricing_preferred_for_mock_services, is_assessor_pricing_preferred_for_supervisory_services', 'numerical', 'integerOnly'=>true),
			array('status', 'length', 'max'=>8),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, maximum_untreated_assessment_for_an_assessor, maximum_untreated_mock_for_an_assessor, maximum_open_supervisory_service_for_an_assessor, is_assessor_pricing_preferred_for_assessment_services, is_assessor_pricing_preferred_for_mock_services, is_assessor_pricing_preferred_for_supervisory_services, status', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'maximum_untreated_assessment_for_an_assessor' => 'Maximum Untreated Assessment For An Assessor',
			'maximum_untreated_mock_for_an_assessor' => 'Maximum Untreated Mock For An Assessor',
			'maximum_open_supervisory_service_for_an_assessor' => 'Maximum Open Supervisory Service For An Assessor',
			'is_assessor_pricing_preferred_for_assessment_services' => 'Is Assessor Pricing Preferred For Assessment Services',
			'is_assessor_pricing_preferred_for_mock_services' => 'Is Assessor Pricing Preferred For Mock Services',
			'is_assessor_pricing_preferred_for_supervisory_services' => 'Is Assessor Pricing Preferred For Supervisory Services',
			'status' => 'Status',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('maximum_untreated_assessment_for_an_assessor',$this->maximum_untreated_assessment_for_an_assessor);
		$criteria->compare('maximum_untreated_mock_for_an_assessor',$this->maximum_untreated_mock_for_an_assessor);
		$criteria->compare('maximum_open_supervisory_service_for_an_assessor',$this->maximum_open_supervisory_service_for_an_assessor);
		$criteria->compare('is_assessor_pricing_preferred_for_assessment_services',$this->is_assessor_pricing_preferred_for_assessment_services);
		$criteria->compare('is_assessor_pricing_preferred_for_mock_services',$this->is_assessor_pricing_preferred_for_mock_services);
		$criteria->compare('is_assessor_pricing_preferred_for_supervisory_services',$this->is_assessor_pricing_preferred_for_supervisory_services);
		$criteria->compare('status',$this->status,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Settings the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
          /**
         * This is the function that deacrivates all settings
         */
        public function isAllSettingsDeactivatedSuccessfully(){
            $counter = 0;
            $model = new Settings;
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $settings = Settings::model()->findAll($criteria); 
            
            foreach($settings as $setting){
                $model->$setting['status'] = "inactive";
                if($model->save()){
                    continue;
                }else{
                    $counter = $counter  + 1;
                }
            }
            
            if($counter == 0){
                return true;
            }else{
                return false;
            }
            
        }
}
