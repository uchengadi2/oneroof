<?php

/**
 * This is the model class for table "assessor_has_courses".
 *
 * The followings are the available columns in table 'assessor_has_courses':
 * @property string $assessor_id
 * @property string $course_id
 * @property string $promise
 * @property string $status
 */
class AssessorHasCourses extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'assessor_has_courses';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('assessor_id, course_id, promise, status', 'required'),
			array('assessor_id, course_id', 'length', 'max'=>10),
			array('promise', 'length', 'max'=>15),
			array('status', 'length', 'max'=>20),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('assessor_id, course_id, promise, status', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'assessor_id' => 'Assessor',
			'course_id' => 'Course',
			'promise' => 'Promise',
			'status' => 'Status',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('assessor_id',$this->assessor_id,true);
		$criteria->compare('course_id',$this->course_id,true);
		$criteria->compare('promise',$this->promise,true);
		$criteria->compare('status',$this->status,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return AssessorHasCourses the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
         /**
         * This is the function that retrieves all active asessors for a course
         */
        public function getAllTheActiveAssessorsOnThisCourse($course_id){
            
                $all_assessors = [];
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='course_id=:courseid and status=:status';
                $criteria->params = array(':courseid'=>$course_id,':status'=>"active");
                $assessors= AssessorHasCourses::model()->findAll($criteria);
                
                //get the information for each of this assessor
                
                foreach($assessors as $assessor){
                  $all_assessors[] = $assessor['assessor_id']; 
                    
                }
                
                return $all_assessors;
            
        }
        
        
        /**
         * This is the function that retrieves an assessor's promise on a course
         */
        public function getTheCoursePromiseOfThisAssessor($course_id,$assessor_id){
            
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='course_id=:courseid and assessor_id=:assessorid';
                $criteria->params = array(':courseid'=>$course_id,':assessorid'=>$assessor_id);
                $assessor= AssessorHasCourses::model()->find($criteria);
                
                return $assessor['promise'];
                
            
        }
}
