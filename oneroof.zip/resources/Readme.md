# ext-theme-neptune-1650f5ed-da2c-4868-a687-9b2942b1d530/resources

This folder contains static resources (typically an `"images"` folder as well).
