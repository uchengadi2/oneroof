<?php

class EducationalServiceController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','removeservice','addnewservice','modifyservice','listAllEducationalServices','listAllCourseEducationalServices','listAllActiveCourseEducationalServices'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','retrieveservicedetails','retrieveeducationalservicedetails','changeservicestatus','listAllActiveCourseEducationalServices'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}
        
        
         /**
         * This is the function that add a new service for a course
         */
        public function actionaddnewservice()
	{
            $model=new EducationalService;
            
            $user_id = Yii::app()->user->id;

		
              $model->name = $_POST['name'];
              $model->course_id = $_POST['course'];
              $model->status = "inactive";
              $model->type = $_POST['type'];
              $model->description = $_POST['description'];
              $model->create_time = new CDbExpression('NOW()');
              $model->create_user_id =$user_id;
              
              if($model->type == 'requested_assessment'){
                  $model->code = 'a';
              }else if($model->type == 'self_assessment'){
                  $model->code = 'b';
              }else if($model->type == 'request_supervised_mock'){
                  $model->code = 'c';
              }else if($model->type == 'request_unsupervised_mock'){
                  $model->code = 'd';
              }else if($model->type == 'self_mock'){
                  $model->code = 'e';
              }else if($model->type == 'supervisory'){
                  $model->code = 'f';
              }else if($model->type == 'practical'){
                  $model->code = 'g';
              }else if($model->type == 'booklending'){
                  $model->code == 'h';
              }else if($model->type == 'equipmentlending'){
                  $model->code = 'j';
              }
                
                if($model->save()){
                     //$data['success'] = 'false';
                     $msg = 'New Service is successfully added';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                  }else{
                       //$result['success'] = 'false';
                         $msg = 'This service was not added, please check with your field validations';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }
               
	}
        
        
         /**
         * This is the function that modifies a service
         */
        public function actionmodifyservice()
	{
            $_id = $_POST['id'];
            $model= EducationalService::model()->findByPk($_id);
            
            $user_id = Yii::app()->user->id;
            
            if(is_numeric($_POST['course'])){
                $course = $_POST['course'];
            }else{
                $course = $_POST['course_id'];
            }

		
              $model->name = $_POST['name'];
              $model->course_id = $course;
              $model->type = $_POST['type'];
              $model->description = $_POST['description'];
              $model->update_time = new CDbExpression('NOW()');
              $model->update_user_id =$user_id;
              
               if($model->type == 'requested_assessment'){
                  $model->code = 'a';
              }else if($model->type == 'self_assessment'){
                  $model->code = 'b';
              }else if($model->type == 'request_supervised_mock'){
                  $model->code = 'c';
              }else if($model->type == 'request_unsupervised_mock'){
                  $model->code = 'd';
              }else if($model->type == 'self_mock'){
                  $model->code = 'e';
              }else if($model->type == 'supervisory'){
                  $model->code = 'f';
              }else if($model->type == 'practical'){
                  $model->code = 'g';
              }else if($model->type == 'booklending'){
                  $model->code == 'h';
              }else if($model->type == 'equipmentlending'){
                  $model->code = 'j';
              }
        
                
                if($model->save()){
                     //$data['success'] = 'false';
                     $msg = 'Service is successfully modified';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                  }else{
                       //$result['success'] = 'false';
                         $msg = 'This service was not modified, please check with your field validations';
                         header('Content-Type: application/json');
                         echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                  }
               
	}
        
        
        
        /**
	 * removes a particular service model.
	
	 */
	public function actionremoveservice()
	{
            $_id = $_POST['id'];
            $model= EducationalService::model()->findByPk($_id);
            
            //get the name of this service
            $service_name = $model->getTheNameOfThisService($_id);
            
           if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$service_name' service is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
	}
	
        
        
        /**
         * This is the function that list all services
         */
        public function actionlistAllEducationalServices(){
            
            $services = EducationalService::model()->findAll();
                if($services===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "service" =>$services
                                        
                                
                            ));
                       
                }
            
        }
        
        
        /**
         * This is the function that list all services for a course
         */
        public function actionlistAllCourseEducationalServices(){
            
                $course_id = $_REQUEST['course_id'];
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='course_id=:id';
                $criteria->params = array(':id'=>$course_id);
                $services= EducationalService::model()->findAll($criteria);
                
                if($services===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                             "service" => $services)
                       );
                       
                }
          
             
        }
        
        
        
         /**
         * This is the function that list all active services for a course
         */
        public function actionlistAllActiveCourseEducationalServices(){
            
                $course_id = $_REQUEST['course_id'];
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='course_id=:id and status=:status';
                $criteria->params = array(':id'=>$course_id,':status'=>"active");
                $services= EducationalService::model()->findAll($criteria);
                
                if($services===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                             "service" => $services)
                       );
                       
                }
          
             
        }
        
           /**
                 * This is the function that retrieves some vital information about a service
                 */
              public function actionretrieveservicedetails(){
                  
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$_REQUEST['service_id']);
                $service= EducationalService::model()->find($criteria);
                
                
                //get the details of the course
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$_REQUEST['course_id']);
                $course= Course::model()->find($criteria);
                
                //get the discipline details
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$_REQUEST['discipline_id']);
                $discipline= Discipline::model()->find($criteria);
                
                //get the institution details
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$_REQUEST['institution_id']);
                $institution= Institution::model()->find($criteria);
                
                             
                //get the per transaction price of this service
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='service_id=:id';
                $criteria->params = array(':id'=>$_REQUEST['service_id']);
                $price= Price::model()->find($criteria);
                
                //get the monthly subscription of this service
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='service_id=:id and frequency=:freq';
                $criteria->params = array(':id'=>$_REQUEST['service_id'], ':freq'=>"monthly");
                $monthly= SubscriptionType::model()->find($criteria);
                
                 //get the quarterly subscription of this service
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='service_id=:id and frequency=:freq';
                $criteria->params = array(':id'=>$_REQUEST['service_id'], ':freq'=>"quarterly");
                $quarterly= SubscriptionType::model()->find($criteria);
                
                //get the half yearly subscription of this service
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='service_id=:id and frequency=:freq';
                $criteria->params = array(':id'=>$_REQUEST['service_id'], ':freq'=>"haif_yearly");
                $half= SubscriptionType::model()->find($criteria);
                
                //get the yearly subscription of this service
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='service_id=:id and frequency=:freq';
                $criteria->params = array(':id'=>$_REQUEST['service_id'], ':freq'=>"yearly");
                $yearly= SubscriptionType::model()->find($criteria);
                
                
                //confirm if user has an active subscription for this service and course
                $is_subscription_active = false;
                
                
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                             "service" => $service['type'],
                           "course" => $course['name'],
                           "course_description" => $course['description'],
                           "discipline" => $discipline['name'],
                           "institution" => $institution['name'],
                           "per_transaction_amount"=>$price['per_transaction_amount'],
                           "monthly"=>$monthly['amount'],
                           "quarterly"=>$quarterly['amount'],
                           "halfly"=>$half['amount'],
                           "yearly"=>$yearly['amount'],
                           "is_subscription_active"=>$is_subscription_active
                               
                               
                               )
                       );
                
              }
              
              
              
               /**
                 * This is the function that retrieves some vital information about a service
                 */
              public function actionretrieveeducationalservicedetails(){
                  
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$_REQUEST['service_id']);
                $service= EducationalService::model()->find($criteria);
                
                
                //get the details of the course
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$service['course_id']);
                $course= Course::model()->find($criteria);
                
                //get the discipline details
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$course['discipline_id']);
                $discipline= Discipline::model()->find($criteria);
                
                //get the institution details
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$discipline['institution_id']);
                $institution= Institution::model()->find($criteria);
                
                //get the preference details
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$institution['preference_id']);
                $preference= Preference::model()->find($criteria);
                
           
                
                
                 header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                             "service" => $service['name'],
                           "course" => $course['name'],
                           "discipline" => $discipline['name'],
                           "institution" => $institution['name'],
                           "preference"=>$preference['name']
                               
                               )
                       );
                
              }

              /**
               * This is the function that changes the status of a service
               */
              public function actionchangeservicestatus(){
                   $_id = $_REQUEST['id'];
                   $model= EducationalService::model()->findByPk($_id);
                   
                   if($_REQUEST['status'] == "inactive"){
                       $model->status = "active";
                   }else{
                       $model->status = "inactive";
                   }
                   
                   if($model->save()){
                      header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() == 0,
                             "msg" => "Service status changed successfully")
                       );
                   }else{
                       header('Content-Type: application/json');
                       echo CJSON::encode(array(
                            "success" => mysql_errno() != 0,
                             "msg" => "Service status could not be changed as there could a data validation issue. Please contact customer service for assistance")
                       );
                   }
                   
              }

	
}
