<?php

/**
 * This is the model class for table "order_has_products".
 *
 * The followings are the available columns in table 'order_has_products':
 * @property string $order_id
 * @property string $product_id
 * @property string $store_id
 * @property integer $number_of_portion
 * @property string $date_ordered
 * @property string $date_last_update
 * @property integer $ordered_by
 * @property integer $updated_by
 */
class OrderHasProducts extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'order_has_products';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('order_id, product_id, store_id', 'required'),
			array('number_of_portion, ordered_by, updated_by', 'numerical', 'integerOnly'=>true),
			array('order_id, product_id, store_id', 'length', 'max'=>10),
			array('date_ordered, date_last_update', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('order_id, product_id, store_id, number_of_portion, date_ordered, date_last_update, ordered_by, updated_by', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'order_id' => 'Order',
			'product_id' => 'Product',
			'store_id' => 'Store',
			'number_of_portion' => 'Number Of Portion',
			'date_ordered' => 'Date Ordered',
			'date_last_update' => 'Date Last Update',
			'ordered_by' => 'Ordered By',
			'updated_by' => 'Updated By',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('order_id',$this->order_id,true);
		$criteria->compare('product_id',$this->product_id,true);
		$criteria->compare('store_id',$this->store_id,true);
		$criteria->compare('number_of_portion',$this->number_of_portion);
		$criteria->compare('date_ordered',$this->date_ordered,true);
		$criteria->compare('date_last_update',$this->date_last_update,true);
		$criteria->compare('ordered_by',$this->ordered_by);
		$criteria->compare('updated_by',$this->updated_by);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return OrderHasProducts the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        /**
         * This is the function that gets the gross amount of products in the cart
         */
        public function getTheTotalGrossAmountOfProductsInTheCart($order_id){
            
            //$model = new Product;
            
            //get all the products in this order
            $products = $this->getAllProductsInThisOrder($order_id);
            
            $sum = 0;
            
            foreach($products as $product){
                
                if($this->isThisProductAPresubscriptionDrawdown($order_id,$product) == false){
                     //get the portion of this product in the cart
                     $number_of_portion = $this->getThePortionOfThisProductInThisOrder($order_id,$product);
                     if($this->isThisARentTransaction($order_id,$product)){
                         //get the rent duration
                         $duration = $this->getTheDurationOfThisRentTransaction($order_id,$product);
                          $sum = $sum + ($this->getThisProductPriceInThisOrder($product,$order_id) * $number_of_portion * $duration);
                     }else if($this->isThisAPaasTransaction($order_id,$product)){
                         $paas_duration = $this->getTheDurationofThisPaasTransaction($order_id,$product);
                         $sum = $sum + ($this->getThisProductPriceInThisOrder($product,$order_id) * $number_of_portion * $paas_duration);
                         
                     }else if($this->isThisAFaasTransaction($order_id,$product)){
                        $faas_duration = $this->getTheDurationofThisFaasTransaction($order_id,$product);
                         $sum = $sum + ($this->getThisProductPriceInThisOrder($product,$order_id) * $number_of_portion * $faas_duration); 
                         
                     }else{
                          $sum = $sum + ($this->getThisProductPriceInThisOrder($product,$order_id) * $number_of_portion);
                     }
                     
                    
                }
               
            }
            
            return $sum;
           
    
            
        }
        
        
        /**
         * This is the function that confirms if a transaction is a rent transactiom
         */
        public function isThisARentTransaction($order_id,$product_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:productid';
             $criteria->params = array(':orderid'=>$order_id,':productid'=>$product_id);
             $order= OrderHasProducts::model()->find($criteria);
             
             if($order['decision'] == 'rent'){
                 return true;
             }else{
                 return false;
             }
        }
        
        /**
         * This is the function that determines if a transacation is a paas transaction
         */
        public function isThisAPaasTransaction($order_id,$product_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:productid';
             $criteria->params = array(':orderid'=>$order_id,':productid'=>$product_id);
             $order= OrderHasProducts::model()->find($criteria);
             
             if($order['decision'] == 'paas'){
                 return true;
             }else{
                 return false;
             }
        }
        
        
         /**
         * This is the function that determines if a transacation is a faas transaction
         */
        public function isThisAFaasTransaction($order_id,$product_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:productid';
             $criteria->params = array(':orderid'=>$order_id,':productid'=>$product_id);
             $order= OrderHasProducts::model()->find($criteria);
             
             if($order['decision'] == 'faas'){
                 return true;
             }else{
                 return false;
             }
        }
        
        
        /**
         * This is the function that retrieves the duration of a paas transaction
         */
        public function getTheDurationofThisPaasTransaction($order_id,$product_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:productid';
             $criteria->params = array(':orderid'=>$order_id,':productid'=>$product_id);
             $order= OrderHasProducts::model()->find($criteria);
             
             return $order['actual_paas_duration'];
            
        }
        
        
         /**
         * This is the function that retrieves the duration of a paas transaction
         */
        public function getTheDurationofThisFaasTransaction($order_id,$product_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:productid';
             $criteria->params = array(':orderid'=>$order_id,':productid'=>$product_id);
             $order= OrderHasProducts::model()->find($criteria);
             
             return $order['actual_faas_duration'];
            
        }
        
        
        /**
         * This is the function that gets the rent duration of a rented transaction in the cart
         */
        public function getTheDurationOfThisRentTransaction($order_id,$product_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:productid';
             $criteria->params = array(':orderid'=>$order_id,':productid'=>$product_id);
             $order= OrderHasProducts::model()->find($criteria);
             
             return $order['actual_rent_duration'];
            
        }
        
        /**
         * This is the function that determines if a transaction in cart is a presubscription drawdown
         */
        public function isThisProductAPresubscriptionDrawdown($order_id,$product_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:productid';
             $criteria->params = array(':orderid'=>$order_id,':productid'=>$product_id);
             $order= OrderHasProducts::model()->find($criteria);
             
             if($order['is_presubscription_drawdown'] == 1){
                 return true;
             }else{
                 return false;
             }
        }
        
        
         /**
         * This is the function that gets a product price in an order
         */
        public function getThisProductPriceInThisOrder($product_id,$order_id){
            
            $model = new Order;
            
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:id and product_id=:productid';
             $criteria->params = array(':id'=>$order_id,':productid'=>$product_id);
             $order= OrderHasProducts::model()->find($criteria);
             
             $order_start_price_validity_date = $this->getThisOrderStartPriceValidityDate($order['order_id'],$order['product_id']); 
            
            $order_end_price_validity_date = $this->getThisOrderEndPriceValidityDate($order['order_id'],$order['product_id']); 
            
            $today = getdate(mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
            
             if($model->isTodayGreaterThanOrEqualToStartValidityDate($today, $order_start_price_validity_date)){
                    if($model->isTodayLessThanOrEqualToEndValidityDate($today,$order_end_price_validity_date)){
                            return  $order['cobuy_member_price_per_item_at_purchase'];
                        }else{
                             return $order['prevailing_retail_selling_price_per_item_at_purchase'];
                        }
                        
                    }else{
                         return $order['prevailing_retail_selling_price_per_item_at_purchase'];
                    }
        }
        
        /**
         * This is the function that gets the discount of all the products in the cart
         */
        public function getTheTotalDiscountAmountOfProductsInTheCart($order_id){
            $model = new Product;
            
            //get all the products in this order
            $products = $this->getAllProductsInThisOrder($order_id);
            
            $sum = 0;
            foreach($products as $product){
                
                 if($this->isThisProductAPresubscriptionDrawdown($order_id,$product)==false){
                     //get the portion of this product in the cart
                    $number_of_portion = $this->getThePortionOfThisProductInThisOrder($order_id,$product);
                    $sum = $sum + ($model->getThePerPortionDiscountAmountOfThisProduct($product,$order_id) * $number_of_portion );
                 }
                
            }
      
            return $sum;
            
        }
        
        
        /**
         * This is the function that gets all the products in this order
         */
        public function getAllProductsInThisOrder($order_id){
            
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:id';
             $criteria->params = array(':id'=>$order_id);
             $orders= OrderHasProducts::model()->findAll($criteria);
             
             $products = [];
             foreach($orders as $order){
                 $products[] = $order['product_id'];
             }
             
             return  $products;
        }
        
        
        /**
         * This is the function that retrieves the portion/quantity of a product ordered for
         */
        public function getThePortionOfThisProductInThisOrder($order_id,$product){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:productid';
             $criteria->params = array(':orderid'=>$order_id,':productid'=>$product);
             $orders= OrderHasProducts::model()->find($criteria);
             
             return $orders['number_of_portion'];
        }
        
        
        /**
         * This is the function that gets the retail selling price from an order
         */
        public function getTheRetailSellingPriceFromThisOrder($order_id,$product_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:productid';
             $criteria->params = array(':orderid'=>$order_id,':productid'=>$product_id);
             $orders= OrderHasProducts::model()->find($criteria);
             
             return $orders['prevailing_retail_selling_price_per_item_at_purchase'];
            
        }
        
        
         /**
         * This is the function that gets the member selling price from an order
         */
        public function getTheMemberSellingPriceFromThisOrder($order_id,$product_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:productid';
             $criteria->params = array(':orderid'=>$order_id,':productid'=>$product_id);
             $orders= OrderHasProducts::model()->find($criteria);
             
             return $orders['cobuy_member_price_per_item_at_purchase'];
            
        }
        
       
        
       
        
        
        
        /**
         * This is the function that adds new product to cart
         */
        public function isThisOrderSuccessfullyAddedToCart($order_id,$product_id,$quantity_of_purchase,$amount_saved_on_purchase,$prevailing_retail_selling_price,$cobuy_member_selling_price,$start_price_validity_period,$end_price_validity_period,$is_escrow_only,$is_escrow_accepted,$is_quote_only,$is_quote_and_escrow,$is_presubscription,$is_presubscription_and_escrow,$is_presubscription_and_drawdown,$is_postsubscription,$is_postsubscription_and_escrow,$is_hamper,$is_mainstore,$is_for_presubscription_topup,$future_trading,$month_of_delivery,$year_of_delivery,$initial_payment_rate,$payment_frequency,$decision,$monthly_paas_subscription_cost,$minimum_quantity_for_paas_subscription,$maximum_quantity_for_paas_subscription,$rent_cost_per_day,$maximum_rent_quantity_per_cycle,$minimum_rent_duration,$minimum_rent_quantity_per_cycle,$actual_rent_duration,$actual_rent_quantity,$paas_product_quantity,$minimum_paas_duration,$maximum_paas_duration,$actual_paas_duration){
            
            //confirm if that product is not already in the cart
            if($this->isProductNotAlreadyInTheCart($order_id,$product_id)){
                if($this->isAddingThisProductToCartASuccess($order_id,$product_id,$quantity_of_purchase,$amount_saved_on_purchase,$prevailing_retail_selling_price,$cobuy_member_selling_price,$start_price_validity_period,$end_price_validity_period,$is_escrow_only,$is_escrow_accepted,$is_quote_only,$is_quote_and_escrow,$is_presubscription,$is_presubscription_and_escrow,$is_presubscription_and_drawdown,$is_postsubscription,$is_postsubscription_and_escrow,$is_hamper,$is_mainstore,$is_for_presubscription_topup,$future_trading,$month_of_delivery,$year_of_delivery,$initial_payment_rate,$payment_frequency,$decision,$monthly_paas_subscription_cost,$minimum_quantity_for_paas_subscription,$maximum_quantity_for_paas_subscription,$rent_cost_per_day,$maximum_rent_quantity_per_cycle,$minimum_rent_duration,$minimum_rent_quantity_per_cycle,$actual_rent_duration,$actual_rent_quantity,$paas_product_quantity,$minimum_paas_duration,$maximum_paas_duration,$actual_paas_duration)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that updates the escrow status of a transaction in cart
         */
        public function isTheUpdateOfTheEscrowStatusOfATransactionASuccess($order_id,$product_id,$is_escrowed,$is_escrow_accepted){
            
             $cmd =Yii::app()->db->createCommand();
            $result = $cmd->update('order_has_products',
                         array('is_escrowed'=>$is_escrowed,
                           'is_escrow_accepted'=>$is_escrow_accepted,
                           
                             
                        ),
                        ("order_id=$order_id and product_id=$product_id")
                          
                     );
            
            if($result>0){
                return true;
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that confirms if product is not already in the cart
         */
        public function isProductNotAlreadyInTheCart($order_id,$product_id){
            
            $cmd =Yii::app()->db->createCommand();
            $cmd->select('COUNT(*)')
                    ->from('order_has_products')
                    ->where("order_id= $order_id and product_id=$product_id");
                $result = $cmd->queryScalar();
                
                if($result == 0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that adds product to cart
         */
        public function isAddingThisProductToCartASuccess($order_id,$product_id,$quantity_of_purchase,$amount_saved_on_purchase,$prevailing_retail_selling_price,$cobuy_member_selling_price,$start_price_validity_period,$end_price_validity_period,$is_escrow_only,$is_escrow_accepted,$is_quote_only,$is_quote_and_escrow,$is_presubscription,$is_presubscription_and_escrow,$is_presubscription_and_drawdown,$is_postsubscription,$is_postsubscription_and_escrow,$is_hamper,$is_mainstore,$is_for_presubscription_topup,$future_trading,$month_of_delivery,$year_of_delivery,$initial_payment_rate,$payment_frequency,$decision,$monthly_paas_subscription_cost,$minimum_quantity_for_paas_subscription,$maximum_quantity_for_paas_subscription,$rent_cost_per_day,$maximum_rent_quantity_per_cycle,$minimum_rent_duration,$minimum_rent_quantity_per_cycle,$actual_rent_duration,$actual_rent_quantity,$paas_product_quantity,$minimum_paas_duration,$maximum_paas_duration,$actual_paas_duration){
            
            if($decision == 'buy'){
                
                if($future_trading == 0){
                     $prevailing_retail_selling_price_value = $prevailing_retail_selling_price;
                     $cobuy_member_selling_price_value = $cobuy_member_selling_price;
                
                }else{
                    $prevailing_retail_selling_price_value =$prevailing_retail_selling_price * $initial_payment_rate;
                    $cobuy_member_selling_price_value = $cobuy_member_selling_price *$initial_payment_rate;
                }
                $amount_saved_per_item_on_this_order =($amount_saved_on_purchase/$quantity_of_purchase);
                $quantity_of_purchases = $quantity_of_purchase;
                
            }else if($decision == 'rent'){
                $prevailing_retail_selling_price_value = $rent_cost_per_day;
                $cobuy_member_selling_price_value = $rent_cost_per_day;
                $amount_saved_per_item_on_this_order = 0;
                $quantity_of_purchases=$actual_rent_quantity;
            }else if($decision == 'paas'){
                $prevailing_retail_selling_price_value = $monthly_paas_subscription_cost;
                $cobuy_member_selling_price_value = $monthly_paas_subscription_cost;
                $amount_saved_per_item_on_this_order=0;
                $quantity_of_purchases=$paas_product_quantity;
                $minimum_paas_duration = $minimum_paas_duration;
                $maximum_paas_duration=$maximum_paas_duration;
                $actual_paas_duration=$actual_paas_duration;
            }
            
            
            
          
            
            
            $cmd =Yii::app()->db->createCommand();
                 $result = $cmd->insert('order_has_products',
                         array('order_id'=>$order_id,
                                'product_id' =>$product_id,
                                'number_of_portion'=>$quantity_of_purchases,
                                 'amount_saved_per_item_on_this_order'=>$amount_saved_per_item_on_this_order,
                                 'prevailing_retail_selling_price_per_item_at_purchase'=>$prevailing_retail_selling_price_value,
                                 'cobuy_member_price_per_item_at_purchase'=>$cobuy_member_selling_price_value,
                                 'is_escrow_only'=>$is_escrow_only,
                                 'is_quote_only'=>$is_quote_only,
                                 'is_quote_and_escrow_only'=>$is_quote_and_escrow,
                                 'is_presubscription'=>$is_presubscription,
                                 'is_presubscription_and_escrow'=>$is_presubscription_and_escrow,
                                 'is_presubscription_drawdown'=>$is_presubscription_and_drawdown,
                                 'is_postsubscription'=>$is_postsubscription,
                                 'is_postsubscription_and_escrow'=>$is_postsubscription_and_escrow,
                                 'is_hamper'=>$is_hamper,
                                 'is_mainstore'=>$is_mainstore,
                                 'is_presubscription_topup'=>$is_for_presubscription_topup,
                                 'future_trading'=>$future_trading,
                                 'month_of_delivery'=>$month_of_delivery,
                                 'year_of_delivery'=>$year_of_delivery,
                                 'initial_payment_rate'=>$initial_payment_rate,
                                 'payment_frequency'=>$payment_frequency,
                                 'is_escrow_accepted'=>$is_escrow_accepted,
                                 'start_price_validity_period'=>$start_price_validity_period,
                                 'end_price_validity_period'=>$end_price_validity_period,
                                 'decision'=>$decision,
                                 'minimum_rent_duration'=>$minimum_rent_duration,
                                 'minimum_rent_quantity_per_cycle'=>$minimum_rent_quantity_per_cycle,
                                 'actual_rent_duration'=>$actual_rent_duration,
                                 'actual_rent_quantity'=>$actual_rent_quantity,
                                 'paas_product_quantity'=>$paas_product_quantity,
                                 'maximum_rent_quantity_per_cycle'=>$maximum_rent_quantity_per_cycle,
                                 'minimum_quantity_for_paas_subscription'=>$minimum_quantity_for_paas_subscription,
                                 'maximum_quantity_for_paas_subscription'=>$maximum_quantity_for_paas_subscription,
                                 'monthly_paas_subscription_cost'=>$monthly_paas_subscription_cost,
                                 'minimum_paas_duration'=>$minimum_paas_duration,
                                 'maximum_paas_duration'=>$maximum_paas_duration,
                                 'actual_paas_duration'=>$actual_paas_duration,
                                 'date_ordered'=>new CDbExpression('NOW()'),
                                 'ordered_by'=>Yii::app()->user->id
                           
                        )
                          
                     );
                 
                 if($result >0){
                     return true;
                 }else{
                     return false;
                 }
            
            
        }
        
        
        /**
         * This is the function that adds a product and its constituents to cart
         */
        public function isThisProductWithConstituentOrderSuccessfullyAddedToCart($order_id,$product_id,$quantity_of_purchase,$amount_saved_on_purchase,$prevailing_retail_selling_price,$cobuy_member_selling_price,$start_price_validity_period,$end_price_validity_period,$is_escrow_only,$is_escrow_accepted,$is_quote_only,$is_quote_and_escrow,$is_presubscription,$is_presubscription_and_escrow,$is_presubscription_and_drawdown,$is_postsubscription,$is_postsubscription_and_escrow,$is_hamper,$is_mainstore,$is_for_presubscription_topup,$future_trading,$month_of_delivery,$year_of_delivery,$initial_payment_rate,$payment_frequency,$decision,$monthly_paas_subscription_cost,$minimum_quantity_for_paas_subscription,$maximum_quantity_for_paas_subscription,$rent_cost_per_day,$maximum_rent_quantity_per_cycle,$minimum_rent_duration,$minimum_rent_quantity_per_cycle,$actual_rent_duration,$actual_rent_quantity,$paas_product_quantity,$minimum_paas_duration,$maximum_paas_duration,$actual_paas_duration){
           if($this->isProductNotAlreadyInTheCart($order_id,$product_id)){
                 if($this->isAddingThisProductWithConstituentToCartASuccess($order_id,$product_id,$quantity_of_purchase,$amount_saved_on_purchase,$prevailing_retail_selling_price,$cobuy_member_selling_price,$start_price_validity_period,$end_price_validity_period,$is_escrow_only,$is_escrow_accepted,$is_quote_only,$is_quote_and_escrow,$is_presubscription,$is_presubscription_and_escrow,$is_presubscription_and_drawdown,$is_postsubscription,$is_postsubscription_and_escrow,$is_hamper,$is_mainstore,$is_for_presubscription_topup,$future_trading,$month_of_delivery,$year_of_delivery,$initial_payment_rate,$payment_frequency,$decision,$monthly_paas_subscription_cost,$minimum_quantity_for_paas_subscription,$maximum_quantity_for_paas_subscription,$rent_cost_per_day,$maximum_rent_quantity_per_cycle,$minimum_rent_duration,$minimum_rent_quantity_per_cycle,$actual_rent_duration,$actual_rent_quantity,$paas_product_quantity,$minimum_paas_duration,$maximum_paas_duration,$actual_paas_duration)){
                     return true;
                 }else {
                     return false;
                 }
                
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that adds a product with constituents to cart
         */
        public function isAddingThisProductWithConstituentToCartASuccess($order_id,$product_id,$quantity_of_purchase,$amount_saved_on_purchase,$prevailing_retail_selling_price,$cobuy_member_selling_price,$start_price_validity_period,$end_price_validity_period,$is_escrow_only,$is_escrow_accepted,$is_quote_only,$is_quote_and_escrow,$is_presubscription,$is_presubscription_and_escrow,$is_presubscription_and_drawdown,$is_postsubscription,$is_postsubscription_and_escrow,$is_hamper,$is_mainstore,$is_for_presubscription_topup,$future_trading,$month_of_delivery,$year_of_delivery,$initial_payment_rate,$payment_frequency,$decision,$monthly_paas_subscription_cost,$minimum_quantity_for_paas_subscription,$maximum_quantity_for_paas_subscription,$rent_cost_per_day,$maximum_rent_quantity_per_cycle,$minimum_rent_duration,$minimum_rent_quantity_per_cycle,$actual_rent_duration,$actual_rent_quantity,$paas_product_quantity,$minimum_paas_duration,$maximum_paas_duration,$actual_paas_duration){
            $model = new OrderHasConstituents;
            if($this->isAddingThisProductToCartASuccess($order_id,$product_id,$quantity_of_purchase,$amount_saved_on_purchase,$prevailing_retail_selling_price,$cobuy_member_selling_price,$start_price_validity_period,$end_price_validity_period,$is_escrow_only,$is_escrow_accepted,$is_quote_only,$is_quote_and_escrow,$is_presubscription,$is_presubscription_and_escrow,$is_presubscription_and_drawdown,$is_postsubscription,$is_postsubscription_and_escrow,$is_hamper,$is_mainstore,$is_for_presubscription_topup,$future_trading,$month_of_delivery,$year_of_delivery,$initial_payment_rate,$payment_frequency,$decision,$monthly_paas_subscription_cost,$minimum_quantity_for_paas_subscription,$maximum_quantity_for_paas_subscription,$rent_cost_per_day,$maximum_rent_quantity_per_cycle,$minimum_rent_duration,$minimum_rent_quantity_per_cycle,$actual_rent_duration,$actual_rent_quantity,$paas_product_quantity,$minimum_paas_duration,$maximum_paas_duration,$actual_paas_duration)){
                if($model->isAddingProductConstituentsToCartASuccess($order_id,$product_id)){
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that retrieves the quantity ordered for by a member
         */
        public function getThisProductQuantityOfPurchaseByThisMember($member_id,$product_id){
            
            $model = new Order;
            
            //get the open order belonging to this member
            $order_id = $model->getTheOpenOrderInitiatedByMember($member_id);
            return $this->getThePortionOfThisProductInThisOrder($order_id,$product_id);
        }
        
        
        /**
         * This is the function that ensures the removal of a product from the cart
         */
        public function isRemovalOfThisProductFromCartForThisMemberSuccessful($member_id,$product_id){
            
            $model = new Order;

            //get this member open order
            $order_id = $model->getTheOpenOrderInitiatedByMember($member_id);
            if($this->doesProductHaveConstituents($product_id)== false){
              if($this->isProductNotAlreadyInTheCart($order_id,$product_id)== false){
                
                if($this->isRemovalOfThisProductSuccessful($order_id,$product_id)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
                
                
            }else{
                if($this->isProductNotAlreadyInTheCart($order_id,$product_id)== false){
                
                if($this->isRemovalOfThisProductWithConstituentsSuccessful($order_id,$product_id)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
            }
               
        }
        
        
        
        /**
         * This is the function that determines if a product has constituents
         */
        public function doesProductHaveConstituents($product_id){
            $model = new ProductConstituents;
            
            return $model->doesProductHaveConstituents($product_id);
        }
        
        /**
         * This is the function that ensures the removal of a product from the cart 
         */
        public function isRemovalOfThisProductSuccessful($order_id,$product_id){
            $cmd =Yii::app()->db->createCommand();
            $result = $cmd->delete('order_has_products', 'order_id=:orderid and product_id=:productid', array(':orderid'=>$order_id,':productid'=>$product_id));
            
            if($result >0){
                return true;
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the functin that effects changes in the products in the cart
         */
        public function isSavingOfChangesInThisProductInCartSuccessful($member_id,$product_id,$quantity_of_purchase,$prevailing_retail_selling_price,$cobuy_member_price,$start_price_validity_period,$end_price_validity_period, $amount_save_on_purchase){
            
            $model = new Order;

            //get this member open order
            $order_id = $model->getTheOpenOrderInitiatedByMember($member_id);
            if($this->isProductNotAlreadyInTheCart($order_id,$product_id)== false){
                
                if($this->isEffectingChangesOfThisProductSuccessful($order_id,$product_id,$quantity_of_purchase,$prevailing_retail_selling_price,$cobuy_member_price,$start_price_validity_period,$end_price_validity_period, $amount_save_on_purchase)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
        }
        
        
      
        
        
        /**
         * This is the function that effects product changes in the cart 
         */
        public function isEffectingChangesOfThisProductSuccessful($order_id,$product_id,$quantity_of_purchase,$prevailing_retail_selling_price,$cobuy_member_price,$start_price_validity_period,$end_price_validity_period,$amount_save_on_purchase){
             $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('order_has_products',
                                  array(
                                    'number_of_portion'=>$quantity_of_purchase,
                                     'prevailing_retail_selling_price_per_item_at_purchase'=>$prevailing_retail_selling_price,
                                     'cobuy_member_price_per_item_at_purchase'=> $cobuy_member_price,
                                      'amount_saved_per_item_on_this_order'=>($amount_save_on_purchase/$quantity_of_purchase),
                                      'start_price_validity_period'=>$start_price_validity_period,
                                      'end_price_validity_period'=>$end_price_validity_period,
                                      'date_last_update'=>new CDbExpression('NOW()')
                                                             
                            ),
                     ("order_id=$order_id and product_id=$product_id"));
            
           if($result>0){
               return true;
           }else{
               return false;
           }
        }
        
        
        
          /**
         * This is the function that modifies the paramters of rent data
         */
        public function isModifyingTheRentParametersASuccess($order_id,$product_id,$quantity_for_rent,$rent_duration){
            
            if($this->isProductNotAlreadyInTheCart($order_id,$product_id)== false){
                
                if($this->isEffectingChangesOfThisRentedProductSuccessful($order_id,$product_id,$quantity_for_rent,$rent_duration)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
        }
        
        
        /**
         * This is the function that modeifies the paas parameter in cart
         */
        public function ifModifyingThePaasParamerIsASuccess($order_id,$product_id,$paas_product_quantity,$actual_paas_duration){
            
             if($this->isProductNotAlreadyInTheCart($order_id,$product_id)== false){
                
                if($this->isEffectingChangesOfThisPaasProductSuccessful($order_id,$product_id,$paas_product_quantity,$actual_paas_duration)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
        }
        
        
        /**
         * This is the function that effects the product's rent modification in cart
         */
        public function isEffectingChangesOfThisRentedProductSuccessful($order_id,$product_id,$quantity_for_rent,$rent_duration){
            
            $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('order_has_products',
                                  array(
                                    'number_of_portion'=>$quantity_for_rent,
                                   'actual_rent_quantity'=>$quantity_for_rent,
                                     'actual_rent_duration'=> $rent_duration,
                                      'date_last_update'=>new CDbExpression('NOW()')
                                                             
                            ),
                     ("order_id=$order_id and product_id=$product_id"));
            
           if($result>0){
               return true;
           }else{
               return false;
           }
        }
        
        
         /**
         * This is the function that effects changes to the paas product's service in cart
         */
        public function isEffectingChangesOfThisPaasProductSuccessful($order_id,$product_id,$paas_product_quantity,$actual_paas_duration){
            
            $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('order_has_products',
                                  array(
                                    'number_of_portion'=>$paas_product_quantity,
                                   'paas_product_quantity'=>$paas_product_quantity,
                                   'actual_paas_duration'=>$actual_paas_duration,   
                                   'date_last_update'=>new CDbExpression('NOW()')
                                                             
                            ),
                     ("order_id=$order_id and product_id=$product_id"));
            
           if($result>0){
               return true;
           }else{
               return false;
           }
        }
        
        
        /**
         * This is the function that removes products with its constituents
         */
          public function isRemovalOfThisProductWithConstituentsSuccessful($order_id,$product_id){
              
              $model = new ProductConstituents;
              
              $member_id = Yii::app()->user->id;
              //get all of this product constituent
              $constituents = $model->getAllProductConstituents($product_id);
              
              $counter = 0;
              
              foreach($constituents as $constituent){
                  //remove the constituent
                  if($this->isRemovalOfThisConstituentSuccessful($order_id,$constituent)){
                      if($this->isConstituentQuantityAmendedByMember($constituent,$member_id)){
                          if($this->isRemovalOfTheAmendedConstituentSuccessful($constituent,$member_id)){
                              $counter = $counter + 1;
                          }
                      }else{
                          $counter = $counter + 1;
                      }
                      
                  }
              }
              
              if($counter >0){
                if($this->isRemovalOfThisProductSuccessful($order_id,$product_id)){
                    return true;
                }else{
                    return false;
                }
              }else{
                  return false;
              }
              
              
          }   
          
          
          /**
           * This is the function that confirms if a constituent had been amended
           */
          public function isConstituentQuantityAmendedByMember($constituent,$member_id){
              $model = new MemberAmendedConstituents;
              return $model->isConstituentQuantityAmendedByMember($constituent,$member_id);
          }
          
          
          
          /**
           * This is the function that confirms if a constituent had been removed from the temporary table
           */
          public function isRemovalOfTheAmendedConstituentSuccessful($constituent,$member_id){
              $model = new MemberAmendedConstituents;
              return $model->isRemovalOfTheAmendedConstituentSuccessful($constituent,$member_id);
          }
          
          /**
           * This is the function that removes constituent from the cart
           */
          public function isRemovalOfThisConstituentSuccessful($order_id,$constituent){
              $model = new OrderHasConstituents;
              
              return $model->isRemovalOfThisConstituentSuccessful($order_id,$constituent);
          }
          
          
           /**
         * This is the function that updates the pack prices after constituents updates
         */
        public function isPackPricesUpdatedSuccessfully($order_id,$product_id,$pack_prevailing_retail_selling_price,$pack_member_selling_price){
            
            $cmd =Yii::app()->db->createCommand();
            $result = $cmd->update('order_has_products',
                         array('prevailing_retail_selling_price_per_item_at_purchase'=>$pack_prevailing_retail_selling_price,
                           'cobuy_member_price_per_item_at_purchase'=>$pack_member_selling_price,
                           
                             
                        ),
                        ("order_id=$order_id and product_id=$product_id")
                          
                     );
            
            if($result>0){
                return true;
            }else{
                return false;
            }
            
        }
        
        
        
        /**
         * This is the function that gets the start price validity period
         */
        public function getThisOrderStartPriceValidityDate($order_id,$product_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:productid';
             $criteria->params = array(':orderid'=>$order_id,':productid'=>$product_id);
             $orders= OrderHasProducts::model()->find($criteria);
             
             return getdate(strtotime($orders['start_price_validity_period']));
            
        }
        
        
        /**
         * This is the function that gets the end price validity period
         */
        public function getThisOrderEndPriceValidityDate($order_id,$product_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:productid';
             $criteria->params = array(':orderid'=>$order_id,':productid'=>$product_id);
             $orders= OrderHasProducts::model()->find($criteria);
             
             return getdate(strtotime($orders['end_price_validity_period']));
            
        }
        
        
        
         /**
         * This is the function that determines if order dates are still valid
         */
        public function isOrderPriceStillValid($order_id,$product_id){
            
            $model = new Order; 
            
            $start_date = $this->getThisOrderStartPriceValidityDate($order_id,$product_id); 
            
            $end_date = $this->getThisOrderEndPriceValidityDate($order_id,$product_id); 
            
            $today = getdate(mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
            
             if($end_date != ""){
              
              if($model->isTodayGreaterThanOrEqualToStartValidityDate($today, $start_date)){
                if($model->isTodayLessThanOrEqualToEndValidityDate($today,$end_date)){
                    return true;
                }else{
                    return false;
                }
            }else{
               return false;
            }
              
          }else{
             return true;
          }
        }
       
        /**
         * This is the function that gets all the remaining quantity of products on sale
         */
        public function getTheRemainingQuantityOfItemsOnSale($product_id,$quantity){
            
            $model = new Order;
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='product_id=:productid';
             $criteria->params = array(':productid'=>$product_id);
             $purchased_quantities= OrderHasProducts::model()->findAll($criteria);
             
             $selected_quantity = 0;
             foreach($purchased_quantities as $purchased){
                 if($model->isOrderOpen($purchased['order_id'])== false){
                      $selected_quantity = $selected_quantity + $purchased['number_of_portion'];
                 }
                
             }
             $remaining_quantity = $quantity - $selected_quantity;
             if($remaining_quantity<0){
                 return 0;
             }else{
                 return  $remaining_quantity;
             }
             
            
            
        }
        
        
        /**
         * This is the function that gets the price of a product in an order
         */
        public function getTheAmountOfThisProductPurchasedInThisOrder($product_id,$order_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:productid';
             $criteria->params = array(':orderid'=>$order_id,':productid'=>$product_id);
             $order= OrderHasProducts::model()->find($criteria);
             
             if($this->isOrderPriceStillValid($order_id,$product_id)){
                 $product_price = $order['number_of_portion'] * $order['cobuy_member_price_per_item_at_purchase'];
                 
             }else{
                 $product_price = $order['number_of_portion'] * $order['prevailing_retail_selling_price_per_item_at_purchase'];
             }
             
             return $product_price;
             
        }
       
        
        /**
         * This is the function that adds a hamper to cart 
         */
        public function isThisHamperOrderSuccessfullyAddedToCart($order_id,$hamper_id,$quantity_of_purchase,$prevailing_retail_selling_price,$cobuy_member_selling_price,$is_hamper,$hamper_terms_and_condition){
            
            $cmd =Yii::app()->db->createCommand();
                 $result = $cmd->insert('order_has_products',
                         array('order_id'=>$order_id,
                                'product_id' =>$hamper_id,
                                'number_of_portion'=>$quantity_of_purchase,
                                 'prevailing_retail_selling_price_per_item_at_purchase'=>$prevailing_retail_selling_price,
                                 'cobuy_member_price_per_item_at_purchase'=>$cobuy_member_selling_price,
                                 'is_hamper'=>$is_hamper,
                                  'hamper_terms_and_condition'=>$hamper_terms_and_condition,
                                  'hamper_terms_and_condition'=>$is_hamper,
                                  'date_ordered'=>new CDbExpression('NOW()'),
                                 'ordered_by'=>Yii::app()->user->id
                           
                        )
                          
                     );
                 
                 if($result >0){
                     return true;
                 }else{
                     return false;
                 }
            
        }
        
        
        /**
         * This is the function that confirms if a product delivery cost is applicable for a delivery
         */
        public function isThisProductDeliveryCostApplicableInThisComputation($order_id,$product_id){
              
             if($this->isProductInTheExclusiveDeliveryCostList($order_id,$product_id) == false){
               if($this->isTransactionAPresubscription($order_id,$product_id) == false){
                     return true;
                 }else{
                     return false;
                 }
                }else{
                 return false;
             }
        }
        
        
        /**
         * This is the function that determines if an order is a presunscription
         */
        public function isTransactionAPresubscription($order_id,$product_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:productid';
             $criteria->params = array(':orderid'=>$order_id,':productid'=>$product_id);
             $order= OrderHasProducts::model()->find($criteria);
             
             if($order['is_presubscription'] == 1){
                 return true;
             }else if($order['is_presubscription_and_escrow'] == 1){
                 return true;
             }else if($order['is_presubscription_topup'] == 1){
                 return true;
             }else{
                 return false;
             }
        }
        
        
        /**
         * This is the function that determines products that are in the exclusive cost list
         */
        public function isProductInTheExclusiveDeliveryCostList($order_id,$product_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:productid';
             $criteria->params = array(':orderid'=>$order_id,':productid'=>$product_id);
             $order= OrderHasProducts::model()->find($criteria);
             
             if($order['is_hamper'] == 1){
                 return true;
             }else if($order['is_quote_only'] == 1){
                 return true;
             }else if($order['is_quote_and_escrow_only'] == 1){
                 return true;
             }else if($order['is_presubscription'] == 1){
                 return true;
             }else if($order['is_presubscription_and_escrow'] == 1){
                 return true;
             }else if($order['is_presubscription_topup'] == 1){
                 return true;
             }else if($order['decision'] == 'faas'){
                 return true;
             }else if($order['decision'] == 'paas'){
                 return true;
             }else{
                 return false;
             }
            
        }
        
        
        /**
         * This is the function that gets the cost of exclusive products in an order 
         */
        public function getTheCostOfDeliveryForExclusiveProductsInAnOrder($order_id){
            $model = new HamperHasBeneficiary;
            
            $total_delivery_cost = 0;
            //get all the exclusive products in the order
            
            $products = $this->getAllProductsInThisOrder($order_id);
            
            foreach($products as $product){
                if($this->isProductInTheExclusiveDeliveryCostList($order_id,$product)){
                    if($this->isThisProductAHamper($order_id,$product)){
                        $total_delivery_cost = $total_delivery_cost + $model->getTheTotalCostOfDeliveryOfThisHamper($product);
                    }else if($this->isThisProductAPreSubscription($order_id,$product)){
                        $total_delivery_cost = 0;
                    }else{
                        $quote_id = $this->getTheQuoteIdOfThisTransaction($order_id,$product);
                       $total_delivery_cost = $total_delivery_cost + $this->getTheCostOfDeliveryOfThisQuote($quote_id); 
                    }
                }
            }
            return $total_delivery_cost;
                    
                    
        }
        
        /**
         * This is the product that confirms if a product is a presubscription
         */
        public function isThisProductAPreSubscription($order_id,$product_id){
            
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:productid';
             $criteria->params = array(':orderid'=>$order_id,':productid'=>$product_id);
             $order= OrderHasProducts::model()->find($criteria);
             
             if($order['is_presubscription_and_escrow'] == 1){
                 return true;
             }else if($order['is_presubscription'] == 1){
                 return true;
             }else if($order['is_presubscription_topup'] == 1){
                 return true;
                 
             }else{
                 return false;
             }
        }
        
        
        /**
         * This is the function that gets the cost of delivery of a quote
         */
        public function getTheCostOfDeliveryOfThisQuote($quote_id){
            $model = new QuoteHasResponse;
            return $model->getTheCostOfDeliveryOfThisQuote($quote_id);
        }
        
        /**
         * This is the function that gets a quote id of a transaction
         */
        public function getTheQuoteIdOfThisTransaction($order_id,$product_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:productid';
             $criteria->params = array(':orderid'=>$order_id,':productid'=>$product_id);
             $order= OrderHasProducts::model()->find($criteria);
             
             return $order['quote_id'];
             
        }
        
        
        /**
         * This is the function that confirms if a product in an order is a hamper
         */
        public function isThisProductAHamper($order_id,$product_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:productid';
             $criteria->params = array(':orderid'=>$order_id,':productid'=>$product_id);
             $order= OrderHasProducts::model()->find($criteria);
             
             if($order['is_hamper'] == 1){
                 return true;
             }else{
                 return false;
             }
        }
        
        
        /**
         * This is the function that calculates the escrow amount in an order
         */
        public function getTheEscrowChargesOfThisOrder($order_id){
            $model = new Escrow;
            $products = $this->getAllProductsInThisOrder($order_id);
            
            $total_escrow_value = 0;
            foreach($products as $product){
                if($this->isThisTransactionEscrowed($order_id,$product)){
                    $escrow_id = $this->getTheEscrowIdOfThisTransaction($order_id,$product);
                    $total_escrow_value = $total_escrow_value + $model->getTheEscrowChargeForThisTransaction($escrow_id);
                }
                
            }
            return $total_escrow_value;
        }
        
        /**
         * This is the function that gets the escrow id of a transaction in the cart
         */
        public function getTheEscrowIdOfThisTransaction($order_id,$product_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:productid';
             $criteria->params = array(':orderid'=>$order_id,':productid'=>$product_id);
             $order= OrderHasProducts::model()->find($criteria);
             
             return $order['escrow_id'];
        }
        
       /**
        * This is the function that determines if a transaction is escrowed
        */
        public function isThisTransactionEscrowed($order_id,$product_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:productid';
             $criteria->params = array(':orderid'=>$order_id,':productid'=>$product_id);
             $order= OrderHasProducts::model()->find($criteria);
             
             if($order['escrow_id']>0){
                 return true;
             }else{
                 return false;
             }
            
        }
        
        
        /**
         * This is the function that confirms if an order contains only exclusive transactions like hampers and quotes
         */
        public function isOrderWithOnlyExclusiveProducts($order_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid';
             $criteria->params = array(':orderid'=>$order_id);
             $products= OrderHasProducts::model()->findAll($criteria);
             
             $counter = 0;
             
             foreach($products as $product){
                 if($this->isProductInTheExclusiveDeliveryCostList($order_id,$product['product_id'])== false){
                     $counter = $counter + 1;
                 }
             }
             if($counter>0){
                 return false;
             }else{
                 return true;
             }
        }
        
        
        /**
         * This is the function that adds a quoted transaction to cart
         */
        public function isAddingThisQuoteToAMemberCartASuccess($quote_id,$product_id,$quantity,$escrow_id,$is_quote_escrowed,$is_escrow_terms_accepted,$total_amount_quoted,$delivery_cost){
            
            $model = new Order;
            
            $member_id = Yii::app()->user->id;
            //get a member open order
            if($model->isMemberWithOpenOrder($member_id)){
                $order_id = $model->getTheOpenOrderInitiatedByMember($member_id);
            }else{
                $order_id = $model->createNewOrderForThisMember($member_id);
            }
            if($this->isProductNotAlreadyInTheCart($order_id,$product_id)){
              if($this->isTheAdditionOfThisQuotedTransactionASuccess($order_id,$quote_id,$product_id,$quantity,$escrow_id,$is_quote_escrowed,$is_escrow_terms_accepted,$total_amount_quoted,$delivery_cost)){
                return true;
                }else{
                    return false;
                }
            }else{
                if($this->isRemovalOfThisProductSuccessful($order_id,$product_id)){
                     if($this->isTheAdditionOfThisQuotedTransactionASuccess($order_id,$quote_id,$product_id,$quantity,$escrow_id,$is_quote_escrowed,$is_escrow_terms_accepted,$total_amount_quoted,$delivery_cost)){
                        return true;
                     }else{
                       return false;
                    }
                }else{
                    return false;
                }
            }
            
            
        }
        
        /**
         * This is the function that add quoted transaction to a member's cart
         */
        public function isTheAdditionOfThisQuotedTransactionASuccess($order_id,$quote_id,$product_id,$quantity_of_purchase,$escrow_id,$is_quote_escrowed,$is_escrow_terms_accepted,$total_amount_quoted,$delivery_cost){
            
            if($escrow_id>0){
                $this_escrow_id = $escrow_id;
                $is_escrow_accepted = $is_escrow_terms_accepted;
                $is_quote_only = 0;
                $is_quote_and_escrow_only = 1;
            }else{
                $this_escrow_id = $escrow_id;
                $is_escrow_accepted = 0;
                $is_quote_only = 1;
                $is_quote_and_escrow_only = 0; 
            }
            $cmd =Yii::app()->db->createCommand();
                 $result = $cmd->insert('order_has_products',
                         array('order_id'=>$order_id,
                                'product_id' =>$product_id,
                                'number_of_portion'=>$quantity_of_purchase,
                                 'prevailing_retail_selling_price_per_item_at_purchase'=>($total_amount_quoted/$quantity_of_purchase),
                                 'cobuy_member_price_per_item_at_purchase'=>($total_amount_quoted/$quantity_of_purchase),
                                 'is_escrow_only'=>0,
                                 'is_quote_only'=>$is_quote_only,
                                 'is_quote_and_escrow_only'=>$is_quote_and_escrow_only,
                                 'is_presubscription'=>0,
                                 'is_presubscription_and_escrow'=>0,
                                 'is_presubscription_drawdown'=>0,
                                 'is_postsubscription'=>0,
                                 'is_postsubscription_and_escrow'=>0,
                                 'is_hamper'=>0,
                                 'is_mainstore'=>0,
                                 'escrow_id'=>$this_escrow_id,
                                 'is_escrow_accepted'=>$is_escrow_accepted,
                                 'quote_id'=>$quote_id,
                                 //'start_price_validity_period'=>$start_price_validity_period,
                                 //'end_price_validity_period'=>$end_price_validity_period,
                                 'date_ordered'=>new CDbExpression('NOW()'),
                                 'ordered_by'=>Yii::app()->user->id
                           
                        )
                          
                     );
                 
                 if($result >0){
                     return true;
                 }else{
                     return false;
                 }
        }
        
        
        /**
         * This is the function that adds presubscribed product drawdowns to cart
         */
        public function isTheAdditionOfThisPrescriptionDrawdownASuccess($member_id,$product_id,$per_delivery_quantity,$is_presubscription_drawdown){
            
            $model = new Order;
            //get the open order for this member
             if($model->isMemberWithOpenOrder($member_id)){
                $order_id = $model->getTheOpenOrderInitiatedByMember($member_id);
            }else{
                $order_id = $model->createNewOrderForThisMember($member_id);
            }
            
            if($this->isProductNotAlreadyInTheCart($order_id,$product_id)){
              if($this->isTheAdditionOfPresubscribedProductDrawdownASuccess($order_id,$product_id,$per_delivery_quantity,$is_presubscription_drawdown)){
                return true;
                }else{
                    return false;
                }
            }else{
                if($this->isRemovalOfThisProductSuccessful($order_id,$product_id)){
                     if($this->isTheAdditionOfPresubscribedProductDrawdownASuccess($order_id,$product_id,$per_delivery_quantity,$is_presubscription_drawdown)){
                        return true;
                     }else{
                       return false;
                    }
                }else{
                    return false;
                }
         }
        }
        
       
        
        /**
         * This is the function that adds presubscribed drawdown products to cart
         */
        public function isTheAdditionOfPresubscribedProductDrawdownASuccess($order_id,$product_id,$per_delivery_quantity,$is_presubscription_drawdown){
            
            $cmd =Yii::app()->db->createCommand();
                 $result = $cmd->insert('order_has_products',
                         array('order_id'=>$order_id,
                                'product_id' =>$product_id,
                                'number_of_portion'=>$per_delivery_quantity,
                                 'prevailing_retail_selling_price_per_item_at_purchase'=>0,
                                 'cobuy_member_price_per_item_at_purchase'=>0,
                                 'is_escrow_only'=>0,
                                 'is_quote_only'=>0,
                                 'is_quote_and_escrow_only'=>0,
                                 'is_presubscription'=>0,
                                 'is_presubscription_and_escrow'=>0,
                                 'is_presubscription_drawdown'=>$is_presubscription_drawdown,
                                 'is_postsubscription'=>0,
                                 'is_postsubscription_and_escrow'=>0,
                                 'is_hamper'=>0,
                                 'is_mainstore'=>0,
                                 'escrow_id'=>0,
                                 'is_escrow_accepted'=>0,
                                 'quote_id'=>0,
                                 //'start_price_validity_period'=>$start_price_validity_period,
                                 //'end_price_validity_period'=>$end_price_validity_period,
                                 'date_ordered'=>new CDbExpression('NOW()'),
                                 'ordered_by'=>Yii::app()->user->id
                           
                        )
                          
                     );
                 
                 if($result >0){
                     return true;
                 }else{
                     return false;
                 }
            
        }
        
        
        /**
         * this is the function that retrieves the amount of all products that could be paid for on delivery
         */
        public function getTheAmountOfPayableOnDeliveryProducts($order_id){
            $model = new Product;

            //get all the products in an order
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid';
             $criteria->params = array(':orderid'=>$order_id);
             $products= OrderHasProducts::model()->findAll($criteria);
             $sum = 0;
             foreach($products as $product){
                 if($model->isProductPayableOnDelivery($product['product_id'])){
                     $sum =$sum + $this->getTheAmountOfThisProductPurchasedInThisOrder($product['product_id'],$order_id);
                 }
             }
             return $sum;
             
        }
        
        
        /**
         * This is the function that gets the amount of products that must be paid before delivery is effected
         */
        public function getTheTotalCostOfPayableBeforeDeliveryProducts($order_id){
            $model = new Product;

            //get all the products in an order
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid';
             $criteria->params = array(':orderid'=>$order_id);
             $products= OrderHasProducts::model()->findAll($criteria);
             $sum = 0;
             foreach($products as $product){
                 if($model->isProductPayableOnDelivery($product['product_id']) == false){
                     $sum =$sum + $this->getTheAmountOfThisProductPurchasedInThisOrder($product['product_id'],$order_id);
                 }
             }
             return $sum;
        }
        
        
        
        /**
         * This is the function that will obtain the cost of delivery of products that could be paid for on delivery
         */
        public function getTheOrderDeliveryCostToThisCityOnPaymentOnDeliveryService($order_id,$city_of_delivery,$payment_method,$delivery_type){
            $model = new Product;
            //get all products in this order that could be payable on delivery
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid';
             $criteria->params = array(':orderid'=>$order_id);
             $products= OrderHasProducts::model()->findAll($criteria);
             $sum = 0;
             foreach($products as $product){
                 if($model->isProductPayableOnDelivery($product['product_id'])){
                     //get the weight of this produt
                     $product_weight = $model->getTheWeightOfThisProduct($product['product_id']);
                     //get the quantity of this product in this order
                     $quantity = $this->getThePortionOfThisProductInThisOrder($order_id, $product['product_id']);
                     $product_total_weight = $product_weight * $quantity;
                     //get this product cost of delivery
                     $product_delivery_cost = $this->getTheDirectCostOfDeliveryOfThisProduct($product_total_weight,$city_of_delivery,$payment_method,$delivery_type);
                     $sum = $sum + $product_delivery_cost;
            
                 }
             }
             return $sum;
        }
        
        
        
        /**
         * This is the function that will obtain the cost of delivery of products that could not be paid for on delivery
         */
        public function getTheOrderDeliveryCostToThisCityOnPaymentByWalletOrOnlineService($order_id,$city_of_delivery,$payment_method,$delivery_type){
            $model = new Product;
            //get all products in this order that could be payable on delivery
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid';
             $criteria->params = array(':orderid'=>$order_id);
             $products= OrderHasProducts::model()->findAll($criteria);
             $sum = 0;
             foreach($products as $product){
                 if($model->isProductPayableOnDelivery($product['product_id']) == false){
                     //get the weight of this produt
                     $product_weight = $model->getTheWeightOfThisProduct($product['product_id']);
                     //get the quantity of this product in this order
                     $quantity = $this->getThePortionOfThisProductInThisOrder($order_id, $product['product_id']);
                     $product_total_weight = $product_weight * $quantity;
                     //get this product cost of delivery
                     $product_delivery_cost = $this->getTheDirectCostOfDeliveryOfThisProduct($product_total_weight,$city_of_delivery,$payment_method,$delivery_type);
                     $sum = $sum + $product_delivery_cost;
            
                 }
             }
             return $sum;
        }
        
        
        /**
         * This is the function that gets teh direct cost of delivery of a product
         */
        public function getTheDirectCostOfDeliveryOfThisProduct($product_total_weight,$city_of_delivery,$payment_method,$delivery_type){
            $model = new City;
            return $model->getTheDirectCostOfDeliveryOfThisProduct($product_total_weight,$city_of_delivery,$payment_method,$delivery_type);
        }
       
        
        /**
         * This is the function that confirms if a product in cart is escrowed only
         */
        public function getTheEscrowStatusOfThisProductInTheCart($order_id,$product_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:prodid';
             $criteria->params = array(':orderid'=>$order_id,':prodid'=>$product_id);
             $product= OrderHasProducts::model()->find($criteria);
             
             return $product['is_escrow_only'];
        }
        
        
        /**
         * This is the function that confirms if a product in cart is both quoted and escrowed 
         */
        public function getTheQuotedAndEscrowStatusOfThisProductInTheCart($order_id,$product_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:prodid';
             $criteria->params = array(':orderid'=>$order_id,':prodid'=>$product_id);
             $product= OrderHasProducts::model()->find($criteria);
             
             return $product['is_quote_and_escrow_only'];
        }
        
        
        /**
         * This is the function that confirms if a product in cart is quoted only
         */
        public function getTheQuotedStatusOfThisProductInTheCart($order_id,$product_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:prodid';
             $criteria->params = array(':orderid'=>$order_id,':prodid'=>$product_id);
             $product= OrderHasProducts::model()->find($criteria);
             
             return $product['is_quote_only'];
        }
        
        
         /**
         * This is the function that retrieves  the escrow id of a product in cart
         */
        public function getTheEscrowIdOfTheProductInTheCart($order_id,$product_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:prodid';
             $criteria->params = array(':orderid'=>$order_id,':prodid'=>$product_id);
             $product= OrderHasProducts::model()->find($criteria);
             
             return $product['escrow_id'];
        }
        
        
          /**
         * This is the function that retrieves  the quote id of a product in cart
         */
        public function getTheQuoteIdOfTheProductInTheCart($order_id, $product_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:prodid';
             $criteria->params = array(':orderid'=>$order_id,':prodid'=>$product_id);
             $product= OrderHasProducts::model()->find($criteria);
             
             return $product['quote_id'];
        }
        
        
        /**
         * This is the function that confirms if there is a hamper in an order
         */
        public function isThereAHamperInThisOrder($order_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid';
             $criteria->params = array(':orderid'=>$order_id);
             $products= OrderHasProducts::model()->findAll($criteria);
             
             foreach($products as $product){
                 if($product['is_hamper'] == 1){
                     return true;
                 }
             }
             return false;
        }
        
        
        /**
         * This is the function that retreieves the prevailing selling price of a hamper in cart
         */
        public function getThePrevailingPriceOfThisProductInCart($order_id,$product_id){
           
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:prodid';
             $criteria->params = array(':orderid'=>$order_id,':prodid'=>$product_id);
             $product= OrderHasProducts::model()->find($criteria);
             
             return $product['prevailing_retail_selling_price_per_item_at_purchase'];
        }
        
        /**
         * Thia is the function that determines if a product is a custom hamper
         */
        public function isThisProductAHamperInCart($order_id,$product_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:prodid';
             $criteria->params = array(':orderid'=>$order_id,':prodid'=>$product_id);
             $product= OrderHasProducts::model()->find($criteria);
             
             return $product['is_hamper'];
        }
        
         /**
         * Thia is the function that determines if a product in cart is quoted
         */
        public function isThisProductInCartQuotedOrEscrowed($order_id,$product_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:prodid';
             $criteria->params = array(':orderid'=>$order_id,':prodid'=>$product_id);
             $product= OrderHasProducts::model()->find($criteria);
             
             if($product['is_quote_only'] == 1){
                 return true;
             }else if($product['is_quote_and_escrow_only'] == 1){
                 return true;
             }else if($product['is_escrow_only'] == 1){
                 return true;
             }else{
                 return false;
             }
        }
        
        
         /**
         * This is the function that retreieves the prevailing selling price of a quoted product in cart
         */
        public function getThePrevailingRetailingPriceForThisQuotedAndEscrowedTransactionInCart($order_id,$product_id){
           
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid and product_id=:prodid';
             $criteria->params = array(':orderid'=>$order_id,':prodid'=>$product_id);
             $product= OrderHasProducts::model()->find($criteria);
             
             return $product['prevailing_retail_selling_price_per_item_at_purchase'];
        }
        
        
        /**
         * This is the function that confirms if there is any non-delivery item in an order
         */
        public function isThereNonOnDeliveryItemInThisOrder($order_id){
             
            $model = new Product; 
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid';
             $criteria->params = array(':orderid'=>$order_id);
             $products= OrderHasProducts::model()->findAll($criteria);
             $counter = 0;
             foreach($products as $product){
                 if($product['is_hamper'] == 1){
                     return true;
                 }else if($product['is_presubscription'] == 1){
                     return true;
                 }else if($product['is_presubscription_and_escrow'] == 1){
                     return true;
                 }else if($product['is_presubscription_topup'] == 1){
                     return true;
                 }else{
                     if($model->isProductPayableOnDelivery($product['product_id'])==false){
                         $counter =  $counter + 1;
                     }
                    
                 }
             }
             if($counter>0){
                 return true;
             }else{
                 return false;
             }
        }
        
       /**
        * This is the function that gets all the products in an order
        */ 
        public function getAllTheProductsInThisOrder($order){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='order_id=:orderid';
             $criteria->params = array(':orderid'=>$order);
             $products= OrderHasProducts::model()->findAll($criteria);
             
             $all_products = [];
             
             foreach($products as $product){
                 $all_products[] = $product['product_id'];
             }
             
             return $all_products;
        }
       
        
        /**
         * This is the functionm that adds faas product to cart
         */
        public function isThisFaasOrderSuccessfullyAddedToCart($order_id,$product_id,$decision,$monthly_faas_subscription_cost,$minimum_quantity_for_faas_subscription,$maximum_quantity_for_faas_subscription,$faas_product_quantity,$minimum_faas_duration,$maximum_faas_duration,$actual_faas_duration,$is_mainstore){
           
             if($this->isProductNotAlreadyInTheCart($order_id,$product_id)){
                 $cmd =Yii::app()->db->createCommand();
                 $result = $cmd->insert('order_has_products',
                         array('order_id'=>$order_id,
                                'product_id' =>$product_id,
                                'number_of_portion'=>$faas_product_quantity,
                                 'prevailing_retail_selling_price_per_item_at_purchase'=>$monthly_faas_subscription_cost,
                                 'cobuy_member_price_per_item_at_purchase'=>$monthly_faas_subscription_cost,
                                 'is_mainstore'=>$is_mainstore,
                                 'decision'=>$decision,
                                 'faas_product_quantity'=>$faas_product_quantity,
                                 'minimum_quantity_for_faas_subscription'=>$minimum_quantity_for_faas_subscription,
                                 'maximum_quantity_for_faas_subscription'=>$maximum_quantity_for_faas_subscription,
                                 'monthly_faas_subscription_cost'=>$monthly_faas_subscription_cost,
                                 'minimum_faas_duration'=>$minimum_faas_duration,
                                 'maximum_faas_duration'=>$maximum_faas_duration,
                                 'actual_faas_duration'=>$actual_faas_duration,
                                 'date_ordered'=>new CDbExpression('NOW()'),
                                 'ordered_by'=>Yii::app()->user->id
                           
                        )
                          
                     );
                 
                 if($result >0){
                     return true;
                 }else{
                     return false;
                 }
                 
             }else{
                 return false;
             }
            
            
        }
        
        
        /**
         * This is the function that modifies the faas parameter in cart
         */
        public function ifModifyingTheFaasParamerIsASuccess($order_id,$product_id,$faas_product_quantity,$actual_faas_duration){
            
             if($this->isProductNotAlreadyInTheCart($order_id,$product_id)== false){
                
                if($this->isEffectingChangesOfThisFaasProductSuccessful($order_id,$product_id,$faas_product_quantity,$actual_faas_duration)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return true;
            }
            
        }
        
        /**
         * This is the function that effects changes to faas product in the cart
         */
        public function isEffectingChangesOfThisFaasProductSuccessful($order_id,$product_id,$faas_product_quantity,$actual_faas_duration){
            
            $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('order_has_products',
                                  array(
                                    'number_of_portion'=>$faas_product_quantity,
                                   'faas_product_quantity'=>$faas_product_quantity,
                                   'actual_faas_duration'=>$actual_faas_duration,   
                                   'date_last_update'=>new CDbExpression('NOW()')
                                                             
                            ),
                     ("(order_id=$order_id and product_id=$product_id)"));
            
           if($result>0){
               return true;
           }else{
               return false;
           }
        }
        
        
        /**
         * This is the function that retrieves all paas product that a member subscribed to
         */
        public function retrieveAllSubscribedPaasProductsForThisMember($member_id){
            
            $model = new Order;
            
            $paas_products = [];
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='ordered_by=:orderby and decision=:decision';
             $criteria->params = array(':orderby'=>$member_id,':decision'=>"paas");
             $products= OrderHasProducts::model()->findAll($criteria);
             
            foreach($products as $product){
                if($model->isThisOrderClosedAndPaymentVerified($product['order_id'])){
                     if($this->isThisAnOnDemandProduct($product['product_id'])== false){
                         $paas_products[] = $product['product_id'];
                     }
                }
             }
           
            return array_unique($paas_products);
            
    
        }
        
        
        /**
         * This is the function that retrieves all subscribed ondemand product for a member
         * 
         */
        public function retrieveAllSubscribedChannelProductsForThisMember($member_id){
            
             $model = new Order;
            
            $ondemand_products = [];
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='ordered_by=:orderby and decision=:decision';
             $criteria->params = array(':orderby'=>$member_id,':decision'=>"paas");
             $products= OrderHasProducts::model()->findAll($criteria);
             
             foreach($products as $product){
                 if($model->isThisOrderClosedAndPaymentVerified($product['order_id'])){
                     if($this->isThisAnOnDemandProduct($product['product_id'])){
                          $ondemand_products[] = $product['product_id'];
                     }
                    
                 }
             }
             return array_unique($ondemand_products);
        }
        
        /**
         * This is the function that determines if a product is ondemand type
         */
        public function isThisAnOnDemandProduct($product_id){
            $model = new Product;
            return $model->isThisAnOnDemandProduct($product_id);
        }
        
        
        /**
         * This is the function that gets all the rented products by a member
         */
        public function getAllTheProductsRentedByThisMember($member_id){
            
             $model = new Order;
            
            $rented_products = [];
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='(ordered_by=:orderby and decision=:decision) and (paas_and_rent_status=:stat or paas_and_rent_status=:status)';
             $criteria->params = array(':orderby'=>$member_id,':decision'=>"rent",':stat'=>"on_consumption",':status'=>"intransit_from_customer");
             $products= OrderHasProducts::model()->findAll($criteria);
             
             foreach($products as $product){
                 if($model->isThisOrderClosedAndPaymentVerified($product['order_id'])){
                     $rented_products[] = $product['product_id'];
                 }
             }
             return array_unique($rented_products);
        }
        
        
        /**
         * This is the function that retrieves all the products bought by a member
         */
        public function getAllTheProductsBoughtByThisMember($member_id){
            
            $model = new Order;
            
            $bought_products = [];
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='ordered_by=:orderby and decision=:decision';
             $criteria->params = array(':orderby'=>$member_id,':decision'=>"buy");
             $products= OrderHasProducts::model()->findAll($criteria);
             
             foreach($products as $product){
                 if($model->isThisOrderClosedAndPaymentVerified($product['order_id'])){
                     $bought_products[] = $product['product_id'];
                 }
             }
             return array_unique($bought_products);
            
        }
        
        /**
         * This is the function that determines if a product is on consumption
         */
        public function isProductOnConsumption($product_id,$member_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='product_id=:prodid and (ordered_by=:orderby and decision=:decision)';
             $criteria->params = array(':orderby'=>$member_id,':decision'=>"paas",':prodid'=>$product_id);
             $product= OrderHasProducts::model()->find($criteria);
             
             if($product['paas_and_rent_status'] == strtolower('on_consumption')){
                 return true;
             }else{
                 return false;
             }
             
        }
        
        /**\
         * This is the function that determines if a product is awaiting consumption
         */
        public function isProductOnAwaitingConsumption($product_id,$member_id){
            
           If($this->isThisProductAlreadyReturned($product_id,$member_id)){
               return true;
           }else{
               if($this->isProductNotAlreadyTakenByMember($product_id,$member_id)){
                   return true;
               }else{
                   return false;
               }
           }
            
            
        }
        
        
        /**
         * This is the function that determines if a product has already been returned
         */
        public function isThisProductAlreadyReturned($product_id,$member_id){
             
            $counter = 0;
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='product_id=:prodid and (ordered_by=:orderby and decision=:decision)';
             $criteria->params = array(':orderby'=>$member_id,':decision'=>"paas",':prodid'=>$product_id);
             $orders= OrderHasProducts::model()->findAll($criteria);
             
             foreach($orders as $order){
                 if($order['paas_and_rent_status'] == strtolower('on_consumption')){
                     $counter = $counter + 1;
                 }else if($order['paas_and_rent_status'] == strtolower('intransit_from_platform')){
                     $counter = $counter + 1;
                 }else if($order['paas_and_rent_status'] == strtolower('intransit_from_customer')){
                     $counter = $counter + 1;
                 }/**else if($order['paas_and_rent_status'] == strtolower('request_for_product')){
                     $counter = $counter + 1;
                 }
                  * 
                  */
             }
             if($counter == 0){
                 return true;
             }else{
                 return false;
             }
             
            
             
        }
        
        
        /**
         * This is the function that determines if a product had not already been taken
         */
        public function isProductNotAlreadyTakenByMember($product_id,$member_id){
            $cmd =Yii::app()->db->createCommand();
            $cmd->select('COUNT(*)')
                    ->from('order_has_products')
                    ->where("(product_id=$product_id and ordered_by=$member_id) and decision='paas'");
                $result = $cmd->queryScalar();
                
                if($result == 0){
                    return true;
                }else{
                    return false;
                }
        }
        
        /**
         * This is the function that determines the highest subscription start date for a product in a bucket
         */
        public function getThisMemberBucketHighestSubscriptionStartDate($bucket_id,$member_id){
            $model = new Product;
            //get all the products in this bucket
            $products = $model->getAllProductsInThisBucket($bucket_id);
            foreach($products as $product){
                if($this->isThisProductAlreadyConsumedByMember($product,$member_id)){
                    $sub_end_date = $this->getStartDateOfThisMemberSubscription($product, $member_id);
                    return $sub_end_date;
                }         
                
            }
           
        }
        
        
        
        /**
         * This is the function that retrieves the start date of a bucket subscription
         */
        public function getStartDateOfThisMemberSubscription($product, $member_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='product_id=:prodid and (ordered_by=:orderby and decision=:decision)';
             $criteria->params = array(':orderby'=>$member_id,':decision'=>"paas",':prodid'=>$product);
             $order= OrderHasProducts::model()->find($criteria);
             
             return $order['subscription_start_date'];
        }
        
        /**
         * This is the function that determines the highest subscription end date for a product in a bucket
         */
        public function getThisMemberBucketHighestSubscriptionEndDate($bucket_id,$member_id){
            $model = new Product;
            //get all the products in this bucket
            $products = $model->getAllProductsInThisBucket($bucket_id);
           
            foreach($products as $product){
                if($this->isThisProductAlreadyConsumedByMember($product,$member_id)){
                    $sub_end_date = $this->getEndDateOfThisMemberSubscription($product, $member_id);
                    return $sub_end_date;
                }         
                
            }
            
           
        }
        
        
        /**
         * This is the function that gets subscription end date for a bucket
         */
        public function getEndDateOfThisMemberSubscription($product, $member_id){
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='product_id=:prodid and (ordered_by=:orderby and decision=:decision)';
             $criteria->params = array(':orderby'=>$member_id,':decision'=>"paas",':prodid'=>$product);
             $order= OrderHasProducts::model()->find($criteria);
             
             return $order['subscription_end_date'];
            
        }
        
        /**
         * This is the function that determines if a product is the latest product under consumption
         */
        public function isThisTheStartDateOfTheLatestProductUnderConsumption($bucket_id,$product,$member_id){
            
            //get all the products under consumption by this member
            $counter =0;
            
            $products_on_consumption = $this->getAllProductsOnConsumptionInThisBucketByAMember($bucket_id,$member_id);
            
            $product_start_date = $this->getTheSubscriptionStartDateOfThisProductInABucketByAMember($product,$member_id);
                  
            foreach($products_on_consumption as $consumption){
                if($this->isThisSubscriptionStartDateHigherThanTheProductStartDate($consumption,$member_id,$product_start_date)){
                    $counter = $counter + 1;
                }
                
            }
            if($counter == 0){
                return true;
            }else{
                return false;
            }
            
       
             
        }
        
        
        /**
         * This is the function that gets all the products in a bucket that are on comsumption
         */
        public function getAllProductsOnConsumptionInThisBucketByAMember($bucket_id,$member_id){
            
            $products = [];
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='paas_and_rent_status=:status and (ordered_by=:orderby and decision=:decision)';
             $criteria->params = array(':orderby'=>$member_id,':decision'=>"paas",':status'=>"on_consumption");
             $orders= OrderHasProducts::model()->findAll($criteria);
             
             foreach($orders as $order){
                 $products[] = $order['product_id'];
             }
             return $products;
        }
        
        /**
         * This is the function that gets the subscription start date of a product
         */
        public function getTheSubscriptionStartDateOfThisProductInABucketByAMember($product,$member_id){
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='(product_id=:prodid and paas_and_rent_status=:status) and (ordered_by=:orderby and decision=:decision)';
             $criteria->params = array(':orderby'=>$member_id,':decision'=>"paas",':prodid'=>$product,':status'=>"on_consumption");
             $order= OrderHasProducts::model()->find($criteria);
             
             return $order['subscription_start_date'];
        }
        
        /**
         * This is the function that compares of a subscription starts date is higher than original product start date
         */
        public function isThisSubscriptionStartDateHigherThanTheProductStartDate($new_product_id,$member_id,$original_product_start_date){
            $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='(product_id=:prodid and paas_and_rent_status=:status) and (ordered_by=:orderby and decision=:decision)';
             $criteria->params = array(':orderby'=>$member_id,':decision'=>"paas",':prodid'=>$new_product_id,':status'=>"on_consumption");
             $order= OrderHasProducts::model()->find($criteria);
             
             if($this->isThisProductStartDateHigherThanTheInitialProduct($order['subscription_start_date'],$original_product_start_date)){
                 return true;
             }else{
                 return false;
             }
        }
        
        
        /**
         * This is the function that compares two subscription starts dates
         */
        public function isThisProductStartDateHigherThanTheInitialProduct($another_product_subscription_start_date,$original_product_start_date){
            return 1;
        }
        
        
        /**
         * This is the function that determines the end date of the latest product on consumption
         */
        public function isThisTheEndDateOfTheLatestProductUnderConsumption($bucket_id,$product,$member_id){
            
             //get all the products under consumption by this member
            $counter =0;
            
            $products_on_consumption = $this->getAllProductsOnConsumptionInThisBucketByAMember($bucket_id,$member_id);
            
            $product_end_date = $this->getTheSubscriptionEndDateOfThisProductInABucketByAMember($product,$member_id);
                  
            foreach($products_on_consumption as $consumption){
                if($this->isThisSubscriptionEndDateHigherThanTheInitialProductEndDate($consumption,$member_id,$product_end_date)){
                    $counter = $counter + 1;
                }
                
            }
            if($counter == 0){
                return true;
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that gets the subscription end date of of a product in a bucket
         */
        public function getTheSubscriptionEndDateOfThisProductInABucketByAMember($product,$member_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='(product_id=:prodid and paas_and_rent_status=:status) and (ordered_by=:orderby and decision=:decision)';
             $criteria->params = array(':orderby'=>$member_id,':decision'=>"paas",':prodid'=>$product,':status'=>"on_consumption");
             $order= OrderHasProducts::model()->find($criteria);
             
             return $order['subscription_end_date'];
        }
        
        /**
         * This is the function that compares the end date of two product on consumption in a bucket
         */
        public function isThisSubscriptionEndDateHigherThanTheInitialProductEndDate($another_product_subscription_end_date,$original_product_end_date){
            
             return 1;
        }
        
        /**
         * This is the function that list all products in a bucket that is on transit from us to a customer
         */
        public function getAllProductsInThisBucketThatAreOnTransitFromUs($bucket_id,$member_id){
            
            $model = new Product;
            
            $products = $model->getAllProductsInThisBucket($bucket_id);
            
            $ontransit = [];
            
            foreach($products as $product){
                 if($this->isThisProductOnTransitFromPlatform($product,$member_id)){
                     $ontransit[] = $product;
                 }
            }
            return $ontransit;
            
            
        }
        
        
         /**
         * This is the function that list all products in a bucket that is on transit from a customer to us
         */
        public function getAllProductsInThisBucketThatAreOnTransitFromYou($bucket_id,$member_id){
            
            $model = new Product;
            
            $products = $model->getAllProductsInThisBucket($bucket_id);
            
            $ontransit = [];
            
            foreach($products as $product){
                 if($this->isThisProductOnTransitFromCustomer($product,$member_id)){
                     $ontransit[] = $product;
                 }
            }
            return $ontransit;
            
            
        }
        
        /**
         * This is the function that determines if a product is on transit from platform
         */
        public function isThisProductOnTransitFromPlatform($product,$member_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='(product_id=:prodid ) and (ordered_by=:orderby and decision=:decision)';
             $criteria->params = array(':orderby'=>$member_id,':decision'=>"paas",':prodid'=>$product);
             $orders= OrderHasProducts::model()->findAll($criteria);
             foreach($orders as $order){
                 if($order['paas_and_rent_status'] == 'intransit_from_platform'){
                         return true;
                    }
             }
            return false;
        }
        
        
        
         /**
         * This is the function that determines if a product is on transit from customer
         */
        public function isThisProductOnTransitFromCustomer($product,$member_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='(product_id=:prodid ) and (ordered_by=:orderby and decision=:decision)';
             $criteria->params = array(':orderby'=>$member_id,':decision'=>"paas",':prodid'=>$product);
             $orders= OrderHasProducts::model()->findAll($criteria);
             
             foreach($orders as $order){
                  if($order['paas_and_rent_status'] == 'intransit_from_customer'){
                        return true;
                    }
             }
            return false;
        }
        
        
        /**
         * This is the function that initiate the return of a product by a customer
         */
        public function isThisPaasProductReturnedSuccessfully($product_id,$member_id,$comment,$quantity){
            
             $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('order_has_products',
                                  array(
                                    'returned_quantity'=>$quantity,
                                   'paas_and_rent_status'=>"intransit_from_customer",
                                   'return_comment'=>$comment,   
                                   'date_intransit_from_customer_initiated'=>new CDbExpression('NOW()')
                                                             
                            ),
                   ("(ordered_by=$member_id and paas_and_rent_status='on_consumption')and (product_id=$product_id and decision='paas')"));
            
           if($result>0){
               return true;
           }else{
               return false;
           }
            
        }
        
        
        /**
         * This is the function that unreturn a product on transit by a customer 
         */
        public function isThisPaasProductUnReturnedSuccessfully($product_id,$member_id,$comment,$quantity){
            
            $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('order_has_products',
                                  array(
                                    'returned_quantity'=>$quantity,
                                   'paas_and_rent_status'=>"on_consumption",
                                   'return_comment'=>$comment,   
                                   'date_intransit_from_customer_initiated'=>NULL
                                                             
                            ),
                   ("(ordered_by=$member_id and paas_and_rent_status='intransit_from_customer')and (product_id=$product_id and decision='paas')"));
            
           if($result>0){
               return true;
           }else{
               return false;
           }
            
        }
        
        
        /**
         * This is the function that determines if no product in a bucket is currently been consumed by this member
         */
        public function isNoProductInThisBucketCurrentlyBeingConsumedByMember($bucket_id,$member_id){
            
            $model = new Product;
             $products = $model->getAllProductsInThisBucket($bucket_id);
             $counter = 0;
             foreach($products as $product){
                 if($this->isThisProductInBucketCurrentlyOnConsumptionByMember($product,$member_id)){
                     $counter =  $counter + 1;
                 }
             }
             if($counter == 0){
                 return true;
             }else{
                 return false;
             }
        }
        
        /**
         * This is the function that determines if a product is currently undersconcumption
         */
        public function isThisProductInBucketCurrentlyOnConsumptionByMember($product,$member_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='(product_id=:prodid ) and (ordered_by=:orderby and decision=:decision)';
             $criteria->params = array(':orderby'=>$member_id,':decision'=>"paas",':prodid'=>$product);
             $order= OrderHasProducts::model()->find($criteria);
             
             if($order['paas_and_rent_status'] == 'on_consumption'){
                 return true;
             }else{
                 return false;
             }
            
        }
        
        
        /**
         * This is the function that determines if request for product placement is successfuk
         */
        public function isRequestForProductPlacementSuccessful($order_id,$product_id,$quantity,$address,$city){
            
            $cmd =Yii::app()->db->createCommand();
            $result = $cmd->insert('order_has_products',
                         array( 
                                 'order_id'=>$order_id,
                                  'product_id'=>$product_id,
                                  'decision'=>"paas",
                                  'paas_and_rent_status'=>'request_for_product',
                                  'paas_product_quantity'=>$quantity,
                                  'number_of_portion'=>$quantity,
                                  'request_delivery_city'=>$city,
                                  'request_delivery_address'=>$address,
                                   'ordered_by'=>Yii::app()->user->id,
                                 'date_ordered'=>new CDbExpression('NOW()')
                           
                        )
                          
                     );
                 
                 if($result >0){
                     return true;
                 }else{
                     return false;
                 }
        }
        
        /**
         * This is the function that retrieves a closed order id of a bucket
         */
        public function generateColdOrderForThisProductInBucketRequest($bucket_id,$member_id){
            $model = new order;
           
            $cold_order_id = $model->createNewColdOrderForThisMember($member_id);
            
            if($model->isOrderClosed($cold_order_id)){
                return $cold_order_id;
            }else{
                return 0;
            }
           
            
            
        }
        
        
        /**
         * This is the function that will confirm if this had already been consumed by the member 
         */
        public function isThisProductAlreadyConsumedByMember($product_id,$member_id){
             $cmd =Yii::app()->db->createCommand();
            $cmd->select('COUNT(*)')
                    ->from('order_has_products')
                    ->where("(product_id=$product_id and ordered_by=$member_id) and decision='paas'");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
        }
        
        /**
         * This is the funtion tat confirms if an order is closed
         */
        public function isOrderOpen($order_id){
            
            $model = new Order;
            return $model->isOrderOpen($order_id);
        }
        
        
        /**
         * This is the function that determines if a product is currently on request
         */
        public function isThisProductAlreadyOnRequest($product,$member_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='ordered_by=:orderby and (product_id=:prodid and decision=:decision)';
            $criteria->params = array(':orderby'=>$member_id,':decision'=>"paas",':prodid'=>$product);
            $orders= OrderHasProducts::model()->findAll($criteria);
            
            foreach($orders as $order){
                if($order['paas_and_rent_status'] == 'request_for_product'){
                    return true;
                }
            }
            return false;
             
        }
        
        
        /**
         * This is the function that confirms the withdrawal of a product request
         */
        public function isTheWithdrawalOfThisPaaSProductRequestASuccess($product_id,$member_id){
            if($this->isThisProductAlreadyOnRequest($product_id,$member_id)){
                if($this->isRequestWithdrawalSuccessful($product_id,$member_id)){
                    return true;
                }else{
                    return false;
                }
                
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that effect the paas customer request withdrawal
         */
        public function isRequestWithdrawalSuccessful($product_id,$member_id){
             $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('order_has_products',
                                  array(
                                   'paas_and_rent_status'=>NULL,
                                    'updated_by'=>Yii::app()->user->id,
                                   'date_last_update'=>new CDbExpression('NOW()')
                                                             
                            ),
                   ("(ordered_by=$member_id and paas_and_rent_status='request_for_product')and (product_id=$product_id and decision='paas')"));
            
           if($result>0){
               return true;
           }else{
               return false;
           }
        }
       
        /**
         * This is the function that confirms if renewal of bucket subscription is a success
         */
        public function isRenewalOfThisBucketByThisMemberASuccess($bucket_id,$order_id,$member_id,$renewal_duration,$monthly_paas_subscription_cost){
            $model = new Product;
            //get all the products in this bucket
             $products = $model->getAllProductsInThisBucket($bucket_id);
             foreach($products as $product){
                 if($this->isThisProductAlreadyConsumedByMember($product,$member_id)){
                     //get the end subscription date of this product in the bucket
                     $current_subscription_end_date = $this->getTheBucketSubscriptionEndDateOfThisProductByAMember($product, $member_id);
                    
                 }
             }
             if($this->isBucketSubscriptionEndDateHigherThanTodaysDate($current_subscription_end_date)){
                 if($this->isTheExtensionOfThisBucketSubscriptionASuccess($bucket_id,$member_id,$renewal_duration,$monthly_paas_subscription_cost,$current_subscription_end_date)){
                     $payment_id = $this->isEffectingBucketChannelOrRentSubscriptionPaymentASuccess($order_id,$member_id,$renewal_duration,$monthly_paas_subscription_cost);
                     if($payment_id>0){
                         return $payment_id;
                     }else{
                        return 0;
                    }
                 }else{
                     return 0;
                 }
             }else{
                 if($this->isBucketSubscriptionRenewalASuccess($bucket_id,$member_id,$renewal_duration,$monthly_paas_subscription_cost,$current_subscription_end_date)){
                     $payment_id = $this->isEffectingBucketChannelOrRentSubscriptionPaymentASuccess($order_id,$member_id,$renewal_duration,$monthly_paas_subscription_cost); 
                     if($payment_id>0){
                         return $payment_id;
                      }else{
                         return 0;
                      }
                 }else{
                     return 0;
                  }
             }
            
        }
        
        
        /**
         * This is the function that gets a members subscription end date
         */
        public function getTheBucketSubscriptionEndDateOfThisProductByAMember($product, $member_id){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='(product_id=:prodid) and (ordered_by=:orderby and decision=:decision)';
             $criteria->params = array(':orderby'=>$member_id,':decision'=>"paas",':prodid'=>$product);
             $order= OrderHasProducts::model()->find($criteria);
             
             return $order['subscription_end_date'];
            
        }
        
        
        /**
         * This is the function that confirms if bucket subscription end date is higher than today
         */
        public function isBucketSubscriptionEndDateHigherThanTodaysDate($subscription_end_date){
            
              $today = getdate(mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
              $end_date = getdate(strtotime($subscription_end_date));
                         
            if($end_date['year'] >$today['year']){
                  return true;
            
              }else if($end_date['year'] ==$today['year']){
                  if($end_date['mon']> $today['mon']){
                      return true;
                  }else if($end_date['mon']== $today['mon']){
                      if($end_date['mday']>= $today['mday']){
                          return true;
                      }else{
                         return false;
                      }
                  }else{
                      return false;
                  }
              }else{
                  return false;
              }
             
                  
          
        
        }   
        
        
        /**
         * This is the function that confirms if the extension of the bucket subscription end date is a success
         */
        public function isTheExtensionOfThisBucketSubscriptionASuccess($bucket_id,$member_id,$renewal_duration,$monthly_paas_subscription_cost,$current_subscription_end_date){
            $model = new Product;
            //get all the products in this bucket
             $products = $model->getAllProductsInThisBucket($bucket_id);
             $count = 0;
             foreach($products as $product){
              if($this->isThisProductAlreadyConsumedByMember($product,$member_id)){
                         $cmd =Yii::app()->db->createCommand();
                        $result = $cmd->update('order_has_products',
                                  array(
                                      'monthly_paas_subscription_cost'=>$monthly_paas_subscription_cost,
                                      'actual_paas_duration'=>$renewal_duration,
                                      'updated_by'=>Yii::app()->user->id,
                                      'date_last_update'=>new CDbExpression('NOW()'),
                                      'subscription_end_date'=>$this->getTheNewSubscriptionEndDateAfterExtension($current_subscription_end_date,$renewal_duration)
                       
                            ),
                        ("product_id=$product and decision='paas' and ordered_by=$member_id"));
            
                        $count = $count + $result;
                     
                 }
                
                
                 
             }
              if($count>0){
                            return true;
                        }else{
                            return false;
                        }
             
        }
        
        /**
         * This is the function that gets the new subscription end date
         */
        public function getTheNewSubscriptionEndDateAfterExtension($old_subscription_end_date,$number_of_months){
           $new_number_of_years = $number_of_months/12;
           $number_of_years = (int)$new_number_of_years;
           $usable_months = ($number_of_months)%12;
           $subscription_current_end_date = getdate(strtotime($old_subscription_end_date));
           
           $new_year = $subscription_current_end_date['year'] + $number_of_years;
           $new_month = $subscription_current_end_date['mon'] + $usable_months;
           $new_day = $subscription_current_end_date['mday'] - 1;
          
           $new_date = (mktime(0, 0, 0, $new_month , $new_day, $new_year));
           
           return date("Y-m-d H:i:s", $new_date);
        }
        
        
        /**
         * This is the function that renews expured bucket subscription
         */
        public function isBucketSubscriptionRenewalASuccess($bucket_id,$member_id,$renewal_duration,$monthly_paas_subscription_cost,$current_subscription_end_date){
            
            $model = new Product;
            //get all the products in this bucket
             $products = $model->getAllProductsInThisBucket($bucket_id);
             $count = 0;
             foreach($products as $product){
              if($this->isThisProductAlreadyConsumedByMember($product,$member_id)){
                         $cmd =Yii::app()->db->createCommand();
                        $result = $cmd->update('order_has_products',
                                  array(
                                      'monthly_paas_subscription_cost'=>$monthly_paas_subscription_cost,
                                      'actual_paas_duration'=>$renewal_duration,
                                      'updated_by'=>Yii::app()->user->id,
                                      'date_last_update'=>new CDbExpression('NOW()'),
                                      'subscription_end_date'=>$this->getTheNewSubscriptionEndDateAfterRenewal($renewal_duration)
                       
                            ),
                        ("product_id=$product and decision='paas' and ordered_by=$member_id"));
            
                       
                     $count = $count + $result;
                 } 
                 
                 
             }
              if($count>0){
                          return true;
                        }else{
                            return false;
                        }
                
        }
        
        
        /**
         * This is the function that provides the bucket subscription end date after renewal
         */
        public function getTheNewSubscriptionEndDateAfterRenewal($number_of_months){
            
             //get the current the end date
            $today = date("Y-m-d H:i:s", mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
            
            return $this->getTheSubscriptionEndDate($today,$number_of_months);
            
        }
        
        /**
         * This is the function that returns the new subscription end date after renewal
         */
        public function getTheSubscriptionEndDate($today,$number_of_months){
           $new_number_of_years = $number_of_months/12;
           $number_of_years = (int)$new_number_of_years;
           $usable_months = ($number_of_months)%12;
           $subscription_current_end_date = getdate(strtotime($today));
           
           $new_year = $subscription_current_end_date['year'] + $number_of_years;
           $new_month = $subscription_current_end_date['mon'] + $usable_months;
           $new_day = $subscription_current_end_date['mday'] - 1;
          
           $new_date = (mktime(0, 0, 0, $new_month , $new_day, $new_year));
           
           return date("Y-m-d H:i:s", $new_date);
        
        }
        
        
        /**
         * This is the function that confirms if the renewal payment is effected successfully
         */
        public function isEffectingBucketChannelOrRentSubscriptionPaymentASuccess($order_id,$member_id,$renewal_duration,$monthly_subscription_cost){
            
            $model = new Payment;
            
           return $model->isEffectingThisTransactionPaymentASuccess($order_id,$member_id,$renewal_duration,$monthly_subscription_cost);
            
          
        }
        
        
        /**
         * This is the function that gets order id of a tranasaction
         */
        public function getTheOrderIdOfThisTransaction($bucket_id,$member_id){
            
          $model = new Product;
            //get all the products in this bucket
             $products = $model->getAllProductsInThisBucket($bucket_id);
             
             foreach($products as $product){
                  if($this->isThisProductAlreadyConsumedByMember($product,$member_id)){
                      $order_id = $this->getOrderIdOfTheTransaction($product,$member_id);
                      return $order_id;
                  }
                  
             }
            return 0;
             
            
        }
        
        /**
         * This is the function that gets the order id of the bucket
         */
        public function getOrderIdOfTheTransaction($product,$member_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='(product_id=:prodid) and (ordered_by=:orderby and decision=:decision)';
             $criteria->params = array(':orderby'=>$member_id,':decision'=>"paas",':prodid'=>$product);
             $order= OrderHasProducts::model()->find($criteria);
             
             return $order['order_id'];
        }
        
        
        /**
         * This is the function that retrieves rent information about a product
         */
        public function getThePrevailingRentOrderIdForThisProduct($product,$member_id){
            
           
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='(product_id=:prodid) and (ordered_by=:orderby and decision=:decision)';
             $criteria->params = array(':orderby'=>$member_id,':decision'=>"rent",':prodid'=>$product);
             $orders= OrderHasProducts::model()->findAll($criteria);
             
             foreach($orders as $order){
                 if($order['paas_and_rent_status'] == "on_consumption"){
                     return $order['order_id'];
                 }else if($order['paas_and_rent_status'] == "intransit_from_customer"){
                     return $order['order_id'];
                 }
             }
             return 0;
        }
        
        
         /**
         * This is the function that initiate the return of a product by a customer
         */
        public function isThisRentedProductReturnedSuccessfully($product_id,$member_id,$comment,$quantity){
            
             $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('order_has_products',
                                  array(
                                    'returned_quantity'=>$quantity,
                                   'paas_and_rent_status'=>"intransit_from_customer",
                                   'return_comment'=>$comment,   
                                   'date_intransit_from_customer_initiated'=>new CDbExpression('NOW()')
                                                             
                            ),
                   ("(ordered_by=$member_id and paas_and_rent_status='on_consumption')and (product_id=$product_id and decision='rent')"));
            
           if($result>0){
               return true;
           }else{
               return false;
           }
            
        }
        
        
        
         /**
         * This is the function that unreturn a product on transit by a customer 
         */
        public function isThisRentedProductUnReturnedSuccessfully($product_id,$member_id,$comment,$quantity){
            
            $cmd =Yii::app()->db->createCommand();
             $result = $cmd->update('order_has_products',
                                  array(
                                    'returned_quantity'=>$quantity,
                                   'paas_and_rent_status'=>"on_consumption",
                                   'return_comment'=>$comment,   
                                   'date_intransit_from_customer_initiated'=>NULL
                                                             
                            ),
                   ("(ordered_by=$member_id and paas_and_rent_status='intransit_from_customer')and (product_id=$product_id and decision='rent')"));
            
           if($result>0){
               return true;
           }else{
               return false;
           }
            
        }
        
        /**
         * This is the function that gets the order id of a rented product under consumption
         */
        public function getTheRentedProductOrderIdOfThisTransaction($product,$member_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='(product_id=:prodid and paas_and_rent_status=:status) and (ordered_by=:orderby and decision=:decision)';
             $criteria->params = array(':orderby'=>$member_id,':decision'=>"rent",':prodid'=>$product,':status'=>'on_consumption');
             $order= OrderHasProducts::model()->find($criteria);
             
             return $order['order_id'];
        }
        
        /**
         * This is the function that confirms if rent extension is successfully done
         */
        public function isExtensionOfThisRentedProductByThisMemberASuccess($product_id,$order_id,$member_id,$renewal_duration,$rent_cost_per_day){
            
            $model = new Payment;
             //get the rent end date of this transaction
            $current_rent_end_date = $this->getTheProductRentEndDateForThisMember($product_id,$order_id);
            
           if($this->isTheExtensionOfThisRentedProductASuccess($order_id,$product_id,$member_id,$renewal_duration,$rent_cost_per_day,$current_rent_end_date)){
               $payment_id = $this->isEffectingBucketChannelOrRentSubscriptionPaymentASuccess($order_id,$member_id,$renewal_duration,$rent_cost_per_day);
                 if($payment_id>0){
                         return $payment_id;
                  }else{
                        return 0;
                  }
                 }else{
                     return 0;
                 }     
                    
        }
        
        
         /**
         * This is the function that gets the end date of this order id 
         */
        public function getTheProductRentEndDateForThisMember($product,$order_id){
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='(product_id=:prodid and paas_and_rent_status=:status) and (order_id=:orderid and decision=:decision)';
             $criteria->params = array(':orderid'=>$order_id,':decision'=>"rent",':prodid'=>$product,':status'=>'on_consumption');
             $order= OrderHasProducts::model()->find($criteria);
             
             return $order['subscription_end_date'];
        }
        
        
        /**
         * This i the function that extends a rent's end date
         */
        public function isTheExtensionOfThisRentedProductASuccess($order_id,$product_id,$member_id,$renewal_duration,$rent_cost_per_day,$current_rent_end_date){
            
            $current_rent_duration = $this->getTheCurrentDurationForThisRent($order_id,$product_id);
            $new_rent_duration = $current_rent_duration + $renewal_duration;
              $cmd =Yii::app()->db->createCommand();
                        $result = $cmd->update('order_has_products',
                                  array(
                                      'rent_cost_per_day'=>$rent_cost_per_day,
                                      'actual_rent_duration'=>$new_rent_duration,
                                      'updated_by'=>Yii::app()->user->id,
                                      'date_last_update'=>new CDbExpression('NOW()'),
                                      'subscription_end_date'=>$this->getTheNewSubscriptionEndDateAfterRentExtension($current_rent_end_date,$renewal_duration)
                       
                            ),
                        ("product_id=$product_id and decision='rent' and order_id=$order_id"));
                        
                        if($result>0){
                            return true;
                        }else{
                            return false;
                        }
       
        }
        
        
        /**
         * This is the function that gets the current rent duration of a transaction
         */
        public function getTheCurrentDurationForThisRent($order_id,$product){
            
             $criteria = new CDbCriteria();
             $criteria->select = '*';
             $criteria->condition='(product_id=:prodid and paas_and_rent_status=:status) and (order_id=:orderid and decision=:decision)';
             $criteria->params = array(':orderid'=>$order_id,':decision'=>"rent",':prodid'=>$product,':status'=>'on_consumption');
             $order= OrderHasProducts::model()->find($criteria);
             
             return $order['actual_rent_duration'];
            
        }
        
        
        /**
         * This is the function that calculates the new subscription end date after rent extension
         */
        public function getTheNewSubscriptionEndDateAfterRentExtension($old_rent_end_date,$renewal_duration_in_days){
            
          // $new_number_of_years = $renewal_duration_in_days/1000;
           //$number_of_years = (int)$new_number_of_years;
           $new_usable_months = ($renewal_duration_in_days)/30;
           $usable_months = (int)$new_usable_months;
           $usable_days = $renewal_duration_in_days%30;
           $subscription_current_end_date = getdate(strtotime($old_rent_end_date));
           
          // $new_year = $subscription_current_end_date['year'] + $number_of_years;
           $new_year = $subscription_current_end_date['year']; 
           $new_month = $subscription_current_end_date['mon'] + $usable_months;
           $new_day = $subscription_current_end_date['mday'] + $usable_days;
          
           $new_date = (mktime(0, 0, 0, $new_month , $new_day, $new_year));
           
           return date("Y-m-d H:i:s", $new_date);
          
        }
        
        
        /**
         * This is the function that determines if channel subscription is active or not
         */
        public function isThisMemberSubscriptionToThisChannelProductActive($subscription_end_date){
            
            if($this->isBucketSubscriptionEndDateHigherThanTodaysDate($subscription_end_date)){
                return true;
            }else{
                return false;
            }
        }
        
}
