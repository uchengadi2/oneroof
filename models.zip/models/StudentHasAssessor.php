<?php

/**
 * This is the model class for table "student_has_assessor".
 *
 * The followings are the available columns in table 'student_has_assessor':
 * @property string $id
 * @property string $student_id
 * @property string $assessor_id
 * @property string $course_id
 * @property string $status
 * @property string $create_time
 *
 * The followings are the available model relations:
 * @property Members $assessor
 * @property Members $student
 * @property SubCourses $course
 */
class StudentHasAssessor extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'student_has_assessor';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('student_id, assessor_id, course_id, status', 'required'),
			array('student_id, assessor_id, course_id', 'length', 'max'=>10),
			array('status', 'length', 'max'=>8),
			array('create_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, student_id, assessor_id, course_id, status, create_time', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'assessor' => array(self::BELONGS_TO, 'Members', 'assessor_id'),
			'student' => array(self::BELONGS_TO, 'Members', 'student_id'),
			'course' => array(self::BELONGS_TO, 'SubCourses', 'course_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'student_id' => 'Student',
			'assessor_id' => 'Assessor',
			'course_id' => 'Course',
			'status' => 'Status',
			'create_time' => 'Create Time',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('student_id',$this->student_id,true);
		$criteria->compare('assessor_id',$this->assessor_id,true);
		$criteria->compare('course_id',$this->course_id,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('create_time',$this->create_time,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return StudentHasAssessor the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that confirms if a student currently has a particular assessor on a course
         */
        public function isThisStudentCurrentlyAssignedToThisAssessorOnThisCourse($student_id,$assessor_id,$course_id){
                            
            $cmd =Yii::app()->db->createCommand();
            $cmd->select('COUNT(*)')
                    ->from('student_has_assessor')
                    ->where("(student_id = $student_id and assessor_id=$assessor_id) and (course_id=$course_id and status='active')");
                $result = $cmd->queryScalar();
                
                if($result > 0){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        /**
         * This is the function that determines if the assigment of a student to an assessor is a success
         */
        public function isTheAssignmentOfThisStudentToThisAssessorASuccess($student_id,$assessor_id,$course_id,$status){
            
            $model = new PlatformSettings;
            
            if($model->hasAssessorReachedHisMaximumStudentLimit($assessor_id)== false){
                  $cmd =Yii::app()->db->createCommand();
                  $result = $cmd->insert('student_has_assessor',
                         array( 'status'=>"$status",
                                 'student_id'=>$student_id,
                                  'assessor_id'=>$assessor_id,
                                  'course_id'=>$course_id,
                                 'create_time'=>new CDbExpression('NOW()')
                           
                        )
                          
                     );
                 
                 if($result >0){
                     return true;
                 }else{
                     return false;
                 }
                
                
            }else{
                
                return false;
            }
           
        }
}
