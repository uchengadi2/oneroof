<?php

/**
 * This is the model class for table "institutions".
 *
 * The followings are the available columns in table 'institutions':
 * @property string $id
 * @property string $name
 * @property string $description
 * @property string $keyword
 * @property string $code
 * @property string $city_id
 * @property string $type
 *
 * The followings are the available model relations:
 * @property Courses[] $courses
 * @property City $city
 */
class Institutions extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'institutions';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('city_id, type', 'required'),
			array('name', 'length', 'max'=>250),
			array('keyword, code', 'length', 'max'=>200),
			array('city_id', 'length', 'max'=>10),
			array('type', 'length', 'max'=>18),
			array('description', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, name, description, keyword, code, city_id, type', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'courses' => array(self::HAS_MANY, 'Courses', 'institution_id'),
			'city' => array(self::BELONGS_TO, 'City', 'city_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'name' => 'Name',
			'description' => 'Description',
			'keyword' => 'Keyword',
			'code' => 'Code',
			'city_id' => 'City',
			'type' => 'Type',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('name',$this->name,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('keyword',$this->keyword,true);
		$criteria->compare('code',$this->code,true);
		$criteria->compare('city_id',$this->city_id,true);
		$criteria->compare('type',$this->type,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Institutions the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that confirms if an institution is a member of a category
         */
        public function isThisInstitutionAMemberOfThisCategory($institution_id,$category_name){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$institution_id);
            $institution = Institutions::model()->find($criteria);
            
            if($institution['type'] == 'olevel'){
                if($category_name == 'olevel'){
                    return true;
                }else{
                    return false;
                }
            }else if($institution['type'] == 'alevel'){
                 if($category_name == 'alevel'){
                    return true;
                }else{
                    return false;
                }
            }else if($institution['type'] == 'tertiary'){
                 if($category_name == 'university'){
                    return true;
                }else if($category_name == 'Polytechnic'){
                    return true;
                }else if($category_name == 'college of education'){
                    return true;
                }else{
                    return false;
                }
            }else if($institution['type'] == 'professional'){
                if($category_name == 'professional'){
                    return true;
                }else{
                    return false;
                }
            }else if($institution['type'] == 'training institute'){
                if($category_name == 'training institute'){
                    return true;
                }else{
                    return false;
                }
            }else if($institution['type'] == 'pre_college'){
                if($category_name == 'Primary'){
                    return true;
                }else if($category_name == 'common entrance'){
                    return true;
                }else{
                    return false;
                }
            }else if($institution['type'] == 'vocational'){
                if($category_name == 'vocational'){
                    return true;
                }else{
                    return false;
                }
            }else if($institution['type'] == 'military & force'){
                if($category_name == 'military & force'){
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
            }
        }
        
        
        /**
         * This is the function that confirms if a category is part of a pre tertiary
         */
        public function isThisCategoryPartOfPreTertiary($category_id){
            $model = new Category;
            
             //get the name of a category
            $category_name = strtolower($model->getCategoryName($category_id));
            
            if($category_name == 'professional'){
                return false;
            }else if($category_name == 'training institute'){
                return false;
            }else if($category_name == 'university'){
                return false;
            }else if($category_name == 'polytechnic'){
                return false;
            }else if($category_name == 'college of education'){
                return false;
            }else if($category_name == 'military & force'){
                return false;
            }else if($category_name == 'vocational'){
                return false;
            }else{
                return true;
            }
            
        }
        
        
        /**
         * This is the function that gets the institution id of a category
         */
        public function getTheInstitutionIdOfThisCategory($category_id){
            
            $model = new Category;
             //get the name of a category
            $category_name = strtolower($model->getCategoryName($category_id));
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='type=:type';
            $criteria->params = array(':type'=>"$category_name");
            $institution = Institutions::model()->find($criteria);
            
            return $institution['id'];
            
        }
        
        /**
         * This is the function that determines if an institution is in a city
         */
        public function isThisInstitutionInThisCity($school_id,$city_id){
            
              
            $cmd =Yii::app()->db->createCommand();
            $cmd->select('COUNT(*)')
                    ->from('courses')
                   ->where("id=$school_id and city_id=$city_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
        }
        
        /**
         * This is the function that gets an institutions entity code
         */
        public function getThisInstitutionEntityCode($institution_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$institution_id);
            $institution = Institutions::model()->find($criteria);
            
            return $institution['code'];
        }
}
