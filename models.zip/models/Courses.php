<?php

/**
 * This is the model class for table "courses".
 *
 * The followings are the available columns in table 'courses':
 * @property string $id
 * @property string $name
 * @property string $description
 * @property string $keyword
 * @property string $institution_id
 * @property string $code
 * @property string $type
 *
 * The followings are the available model relations:
 * @property Institutions $institution
 */
class Courses extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'courses';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('institution_id, type', 'required'),
			array('name', 'length', 'max'=>250),
			array('keyword, code', 'length', 'max'=>200),
			array('institution_id', 'length', 'max'=>10),
			array('type', 'length', 'max'=>20),
			array('description', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, name, description, keyword, institution_id, code, type', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'institution' => array(self::BELONGS_TO, 'Institutions', 'institution_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'name' => 'Name',
			'description' => 'Description',
			'keyword' => 'Keyword',
			'institution_id' => 'Institution',
			'code' => 'Code',
			'type' => 'Type',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('name',$this->name,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('keyword',$this->keyword,true);
		$criteria->compare('institution_id',$this->institution_id,true);
		$criteria->compare('code',$this->code,true);
		$criteria->compare('type',$this->type,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Courses the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        /**
         * This is the function that retrieves the keyword of a subject or a course
         */
        public function getTheKeywordStringForThisCourseOrSubject($subject_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$subject_id);
            $course = Courses::model()->find($criteria);
            
            return $course['keyword'];
        }
        
        
        /**
         * This is the function that determines if a course/subject is available in a school
         */
        public function isThisSubjectOrCourseAvailableInThisSchool($school_id,$subject_id){
            
               $cmd =Yii::app()->db->createCommand();
            $cmd->select('COUNT(*)')
                    ->from('courses')
                   ->where("id=$subject_id and institution_id=$school_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
                
            
        }
        
        
          /**
         * This is the function that gets the product type of a product based on the subject or course id
         */
        public function getTheProductTypeOfThisCategoryBasedOnTheSubjectOrCourseId($subject_id){
            
             $model = new ProductType;
            //get the code of this subject/course
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';   
            $criteria->params = array(':id'=>$subject_id);
            $course = Courses::model()->find($criteria);
            
            $product_type_id = $model->getTheProductTypeOfThisSubjectOrCourse($course['code']);
            
            return $product_type_id;
         
        }
        
        
        
         /**
         * This is the function that gets an institutions entity code
         */
        public function getTheGeneralCourseCodeOfThisCourse($course_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$course_id);
            $course = Courses::model()->find($criteria);
            
            return $course['code'];
        }
        
        
        /**
         * This is the function that retrieves all the non discipline courses
         */
        public function getAllTheNonDiscioplineCoursesOfThisDisciplineCourse($course_id,$institution_id){
            
            //get the generic course code
            $generic_course_code = $this->getTheGenericCourseCodeOfThisCourse($course_id);
            
            $all_courses = [];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='(general_course_code=:code and classification=:class) and institution_id=:instid';
            $criteria->params = array(':code'=>$generic_course_code,':class'=>"course",':instid'=>$institution_id);
            $courses = Courses::model()->findAll($criteria);
            
            foreach($courses as $course){
                $all_courses[] = $course['id'];
            }
            
            return $all_courses;
            
        }
        
        
        
        /**
         * This is the function that gets a generic code i=of a course discipline
         */
        public function getTheGenericCourseCodeOfThisCourse($course_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$course_id);
            $course = Courses::model()->find($criteria);
            
            return $course['general_course_code'];
        }
        
        
        /**
         * This is the function that gets a course code
         */
        public function getTheCourseCodeOfThisCourse($course_id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$course_id);
            $course = Courses::model()->find($criteria);
            
            return $course['code'];
        }
      
        
        /**
         * This is the function that retrieves all course with similar codes
         */
        public function getAllTheCoursesWithThisCode($course_code){
            
            $all_courses = [];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='code=:code';
            $criteria->params = array(':code'=>$course_code);
            $courses = Courses::model()->findAll($criteria);
            
            foreach($courses as $course){
                $all_courses[] = $course['id'];
            }
            
            return array_unique($all_courses);
            
        }
}
