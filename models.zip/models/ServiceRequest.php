<?php

/**
 * This is the model class for table "service_request".
 *
 * The followings are the available columns in table 'service_request':
 * @property string $id
 * @property string $service_id
 * @property string $student_id
 * @property string $course_id
 * @property string $discipline_id
 * @property string $institution_id
 * @property string $difficulty
 * @property integer $is_request_selected_by_assessor
 * @property integer $is_service_supervisory_learning
 * @property string $assessment_request_limit
 * @property string $date_requested
 * @property integer $requested_by
 * @property string $filename
 * @property string $service_request_code
 *
 * The followings are the available model relations:
 * @property Discipline $discipline
 * @property Institution $institution
 * @property Course $course
 * @property EducationalService $service
 * @property Members $student
 */
class ServiceRequest extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'service_request';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('service_id, student_id, course_id, discipline_id, institution_id, difficulty', 'required'),
			array('is_request_selected_by_assessor, is_service_supervisory_learning, requested_by', 'numerical', 'integerOnly'=>true),
			array('service_id, student_id, course_id, discipline_id, institution_id', 'length', 'max'=>10),
			array('difficulty', 'length', 'max'=>14),
			array('filename, service_request_code', 'length', 'max'=>200),
			array('assessment_request_limit, date_requested', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, service_id, student_id, course_id, discipline_id, institution_id, difficulty, is_request_selected_by_assessor, is_service_supervisory_learning, assessment_request_limit, date_requested, requested_by, filename, service_request_code', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'discipline' => array(self::BELONGS_TO, 'Discipline', 'discipline_id'),
			'institution' => array(self::BELONGS_TO, 'Institution', 'institution_id'),
			'course' => array(self::BELONGS_TO, 'Course', 'course_id'),
			'service' => array(self::BELONGS_TO, 'EducationalService', 'service_id'),
			'student' => array(self::BELONGS_TO, 'Members', 'student_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'service_id' => 'Service',
			'student_id' => 'Student',
			'course_id' => 'Course',
			'discipline_id' => 'Discipline',
			'institution_id' => 'Institution',
			'difficulty' => 'Difficulty',
			'is_request_selected_by_assessor' => 'Is Request Selected By Assessor',
			'is_service_supervisory_learning' => 'Is Service Supervisory Learning',
			'assessment_request_limit' => 'Assessment Request Limit',
			'date_requested' => 'Date Requested',
			'requested_by' => 'Requested By',
			'filename' => 'Filename',
			'service_request_code' => 'Service Request Code',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('service_id',$this->service_id,true);
		$criteria->compare('student_id',$this->student_id,true);
		$criteria->compare('course_id',$this->course_id,true);
		$criteria->compare('discipline_id',$this->discipline_id,true);
		$criteria->compare('institution_id',$this->institution_id,true);
		$criteria->compare('difficulty',$this->difficulty,true);
		$criteria->compare('is_request_selected_by_assessor',$this->is_request_selected_by_assessor);
		$criteria->compare('is_service_supervisory_learning',$this->is_service_supervisory_learning);
		$criteria->compare('assessment_request_limit',$this->assessment_request_limit,true);
		$criteria->compare('date_requested',$this->date_requested,true);
		$criteria->compare('requested_by',$this->requested_by);
		$criteria->compare('filename',$this->filename,true);
		$criteria->compare('service_request_code',$this->service_request_code,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return ServiceRequest the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that generates the service code
         */
        public function generateThisServiceRequestCode( $service_id,$institution_id){
           
            $model = new Institution;
            
            //get the preference of this institution
            $preference_id = $model->getThePreferenceOfThisInstitution($institution_id);
             //get this institution preference code or alphabet
            $preference_alphabet = $this->getThisInstitutionPreferenceAlphabet($preference_id);
            
            //get the next code value for this 
            $next_value = $this->getTheNextCodeValueOfThisPreferenceAndService($service_id,$preference_id);
            
            //get this service code alphabet
            $service_alphabet = $this->getThisServiceCodeAlphabet($service_id);
            
            $request_code = $preference_alphabet.$next_value.$service_alphabet;
            
            return $request_code;
                    
            
        }
        
        
        /**
         * This is the function that retrieves a preference code
         */
        public function getThisInstitutionPreferenceAlphabet($preference_id){
            $model = new Preference;
            return $model->getThisInstitutionPreferenceAlphabet($preference_id);
        }
        
        
        /**
         * This is the function that gets a service code
         */
        public function getThisServiceCodeAlphabet($service_id){
            $model = new EducationalService;
            return $model->getThisServiceCodeAlphabet($service_id);
        }
        
        
        /**
         * This is the function that gets the next code value of a prefetrence and service
         */
        public function getTheNextCodeValueOfThisPreferenceAndService($service_id,$preference_id){
            $model = new CodeCounter;
            return $model->getTheNextCodeValueOfThisPreferenceAndService($service_id,$preference_id);
        }
        
        
       
}
