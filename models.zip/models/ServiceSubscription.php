<?php

/**
 * This is the model class for table "service_subscription".
 *
 * The followings are the available columns in table 'service_subscription':
 * @property string $id
 * @property string $student_id
 * @property string $course_id
 * @property string $service_id
 * @property string $frequency
 * @property string $status
 * @property string $subscription_start_date
 * @property string $subscription_end_date
 * @property integer $subscription_activated_by
 *
 * The followings are the available model relations:
 * @property Members $student
 * @property EducationalService $service
 * @property Course $course
 */
class ServiceSubscription extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'service_subscription';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('student_id, course_id, service_id, frequency, status', 'required'),
			array('subscription_activated_by', 'numerical', 'integerOnly'=>true),
			array('student_id, course_id, service_id', 'length', 'max'=>10),
			array('frequency', 'length', 'max'=>11),
			array('status', 'length', 'max'=>8),
			array('subscription_start_date, subscription_end_date', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, student_id, course_id, service_id, frequency, status, subscription_start_date, subscription_end_date, subscription_activated_by', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'student' => array(self::BELONGS_TO, 'Members', 'student_id'),
			'service' => array(self::BELONGS_TO, 'EducationalService', 'service_id'),
			'course' => array(self::BELONGS_TO, 'Course', 'course_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'student_id' => 'Student',
			'course_id' => 'Course',
			'service_id' => 'Service',
			'frequency' => 'Frequency',
			'status' => 'Status',
			'subscription_start_date' => 'Subscription Start Date',
			'subscription_end_date' => 'Subscription End Date',
			'subscription_activated_by' => 'Subscription Activated By',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('student_id',$this->student_id,true);
		$criteria->compare('course_id',$this->course_id,true);
		$criteria->compare('service_id',$this->service_id,true);
		$criteria->compare('frequency',$this->frequency,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('subscription_start_date',$this->subscription_start_date,true);
		$criteria->compare('subscription_end_date',$this->subscription_end_date,true);
		$criteria->compare('subscription_activated_by',$this->subscription_activated_by);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return ServiceSubscription the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that confirms if a subscription is successful or not
         */
        public function isSubscriptionToThisServiceForThisUserASuccess($user_id,$service_id,$course_id,$frequency){
            $model = new ServiceSubscription;
            
            $model->student_id = $user_id;
            $model->course_id = $course_id;
            $model->service_id = $service_id;
            $model->frequency=$frequency;
            $model->status = "inactive";
           //$model->subscription_start_date = new CDbExpression('NOW()');
           // $model->subscription_end_date = $this->getTheSubscriptionEndDate($frequency);
            
            if($model->save()){
                return true;
            }else{
                return false;
            }
        }
        
        /**
         * This is the function that calculates an end date of a subscription
         */
        public function getTheSubscriptionEndDate($frequency){
            if($frequency == "monthly"){
                $day = 30;
            }else if($frequency == "quarterly"){
                $day = 90;
            }else if($frequency == "haif_yearly"){
                $day = 180;
            }else if($frequency == "yearly"){
                $day = 360;
            }
            
            
        }
}
