<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of ImageCreators
 *
 * @author Uche
 */
class ImageCreators extends CActiveRecord {
    //put your code here
    
    /**
     * This is the function that saves new image to a any model
     */
    public function saveThisImageToItModel($model){
        
        
        
    }
}
