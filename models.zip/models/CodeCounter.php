<?php

/**
 * This is the model class for table "code_counter".
 *
 * The followings are the available columns in table 'code_counter':
 * @property string $id
 * @property string $preference_id
 * @property string $service_id
 * @property integer $current_value
 *
 * The followings are the available model relations:
 * @property Preference $preference
 * @property EducationalService $service
 */
class CodeCounter extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'code_counter';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('preference_id, service_id', 'required'),
			array('current_value', 'numerical', 'integerOnly'=>true),
			array('preference_id, service_id', 'length', 'max'=>10),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, preference_id, service_id, current_value', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'preference' => array(self::BELONGS_TO, 'Preference', 'preference_id'),
			'service' => array(self::BELONGS_TO, 'EducationalService', 'service_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'preference_id' => 'Preference',
			'service_id' => 'Service',
			'current_value' => 'Current Value',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('preference_id',$this->preference_id,true);
		$criteria->compare('service_id',$this->service_id,true);
		$criteria->compare('current_value',$this->current_value);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return CodeCounter the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
         /**
         * This is the function that gets the next code value of a prefetrence and service
         */
        public function getTheNextCodeValueOfThisPreferenceAndService($service_id,$preference_id){
            $model = new CodeCounter;
            $next_code = 0;
            if($this->isExitCodeCounterForServiceAndPreference($service_id,$preference_id)){
                     $criteria = new CDbCriteria();
                     $criteria->select = '*';
                     $criteria->condition='service_id=:servid and preference_id=:preid';
                     $criteria->params = array(':servid'=>$service_id,':preid'=>$preference_id);
                     $code= CodeCounter::model()->find($criteria); 
                     
                     $next_code = $code['current_value'] + 1;
                     if($this->isSettingTheNewCurrentCodeASuccess($code['id'],$next_code)){
                         return $next_code;
                     }else{
                        return $next_code; 
                     }
              }else{
                $model->service_id = $service_id;
                $model->preference_id = $preference_id;
                
                if($model->save()){
                     $criteria = new CDbCriteria();
                     $criteria->select = '*';
                     $criteria->condition='id=:id';
                     $criteria->params = array(':id'=>$model->id);
                     $code= CodeCounter::model()->find($criteria);
                     
                     $next_code = $code['current_value'];
                      if($this->isSettingTheNewCurrentCodeASuccess($code['id'],$next_code)){
                         return $next_code;
                     }else{
                         return $next_code;
                     }
                }
            }
          
        }
        
        /**
         * This function sets the new code current value
         */
        public function isSettingTheNewCurrentCodeASuccess($id,$next_code){
           
             $model= CodeCounter::model()->findByPk($id);
             $model->current_value = $next_code;
             
             if($model->save()){
                 return true;
             }else{
                 return false;
             }
            
      
        }
        
        
        /**
         * This is the function that determines if a code counter exist for a preference and service
         */
        public function isExitCodeCounterForServiceAndPreference($service_id,$preference_id){
             $cmd =Yii::app()->db->createCommand();
            $cmd->select('COUNT(*)')
                    ->from('code_counter')
                   ->where("service_id=$service_id and preference_id=$preference_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
       
}
