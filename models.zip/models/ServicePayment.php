<?php

/**
 * This is the model class for table "service_payment".
 *
 * The followings are the available columns in table 'service_payment':
 * @property string $id
 * @property string $student_id
 * @property string $course_id
 * @property string $service_id
 * @property string $payment_type
 * @property string $payment_method
 * @property string $status
 * @property double $amount
 * @property string $payment_date
 * @property string $payment_confirmation_date
 * @property integer $payment_confirmed_by
 *
 * The followings are the available model relations:
 * @property Members $student
 * @property Course $course
 * @property EducationalService $service
 */
class ServicePayment extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'service_payment';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('student_id, course_id, service_id, payment_type, payment_method, status', 'required'),
			array('payment_confirmed_by', 'numerical', 'integerOnly'=>true),
			array('amount', 'numerical'),
			array('student_id, course_id, service_id', 'length', 'max'=>10),
			array('payment_type', 'length', 'max'=>15),
			array('payment_method', 'length', 'max'=>6),
			array('status', 'length', 'max'=>11),
			array('payment_date, payment_confirmation_date', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, student_id, course_id, service_id, payment_type, payment_method, status, amount, payment_date, payment_confirmation_date, payment_confirmed_by', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'student' => array(self::BELONGS_TO, 'Members', 'student_id'),
			'course' => array(self::BELONGS_TO, 'Course', 'course_id'),
			'service' => array(self::BELONGS_TO, 'EducationalService', 'service_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'student_id' => 'Student',
			'course_id' => 'Course',
			'service_id' => 'Service',
			'payment_type' => 'Payment Type',
			'payment_method' => 'Payment Method',
			'status' => 'Status',
			'amount' => 'Amount',
			'payment_date' => 'Payment Date',
			'payment_confirmation_date' => 'Payment Confirmation Date',
			'payment_confirmed_by' => 'Payment Confirmed By',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('student_id',$this->student_id,true);
		$criteria->compare('course_id',$this->course_id,true);
		$criteria->compare('service_id',$this->service_id,true);
		$criteria->compare('payment_type',$this->payment_type,true);
		$criteria->compare('payment_method',$this->payment_method,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('amount',$this->amount);
		$criteria->compare('payment_date',$this->payment_date,true);
		$criteria->compare('payment_confirmation_date',$this->payment_confirmation_date,true);
		$criteria->compare('payment_confirmed_by',$this->payment_confirmed_by);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return ServicePayment the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
         /**
         * This is the function that confirms if service payment
         */
        public function isPaymentASuccess($user_id,$service_id,$course_id,$amount,$payment_type,$payment_method){
            $model = new ServicePayment;
            
            $model->student_id = $user_id;
            $model->course_id = $course_id;
            $model->service_id = $service_id;
            $model->payment_type=$payment_type;
            $model->payment_method=$payment_method;
            $model->status = "unconfirmed";
            $model->amount = $amount;
            $model->payment_date = new CDbExpression('NOW()');
         
            if($model->save()){
                return true;
            }else{
                return false;
            }
        }
}
